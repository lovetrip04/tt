# WeatherTrip - Weather-Integrated Route Planner

A comprehensive road trip planning platform that provides intelligent weather-integrated route analysis for travelers. WeatherTrip enables users to make informed travel decisions by combining advanced meteorological insights with interactive route mapping.

## Features

- **Route Planning**: Search and visualize routes between any two locations
- **Weather Forecasting**: View detailed weather forecasts along your route for up to 10 days
- **Rain Visualization**: Highlight rain and adverse weather conditions along your journey
- **Day Selection**: See how weather changes throughout your trip with the day selector
- **Location Autocomplete**: Easily find US cities with built-in location suggestions

## Technologies Used

- **Frontend**: React, TypeScript, TailwindCSS, Shadcn UI Components
- **Backend**: Node.js, Express
- **Mapping**: OpenStreetMap with Leaflet
- **Routing**: OSRM (Open Source Routing Machine)
- **Geocoding**: Nominatim
- **Weather Data**: Open-Meteo API
- **Database**: PostgreSQL with Drizzle ORM

## Open Source Stack

WeatherTrip uses only 100% free, open-source services with no commercial restrictions:

- **OpenStreetMap**: For map tiles and base mapping
- **Nominatim**: For geocoding locations
- **OSRM**: For routing between locations
- **Open-Meteo**: For weather forecasting data

## Getting Started

1. Clone the repository
2. Install dependencies with `npm install`
3. Start the development server with `npm run dev`

## Future Enhancements

- Multiple waypoints support
- Elevation profiles with weather changes
- Historical weather data comparison
- Trip sharing capabilities