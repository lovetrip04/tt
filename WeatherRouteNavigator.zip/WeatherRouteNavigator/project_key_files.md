# WeatherTrip Project - Key Files

This document lists the key files of the WeatherTrip project for reference.

## Project Structure

### Frontend

- **App & Main Components**
  - `client/src/App.tsx` - Main application component
  - `client/src/main.tsx` - Entry point
  - `client/src/pages/Home.tsx` - Home page component
  
- **Map Components**
  - `client/src/components/MapContainer.tsx` - Map display with route and weather data
  - `client/src/components/MapLegend.tsx` - Legend for map symbols
  
- **User Interface Components**
  - `client/src/components/Sidebar.tsx` - Sidebar with trip form and weather forecast
  - `client/src/components/TripForm.tsx` - Form for entering trip details
  - `client/src/components/WeatherForecast.tsx` - Weather forecast display
  - `client/src/components/WeatherCard.tsx` - Individual weather forecast card
  - `client/src/components/ui/location-autocomplete.tsx` - Location search with autocomplete

### Backend

- **Server Components**
  - `server/index.ts` - Main server setup
  - `server/routes.ts` - API routes definition
  - `server/vite.ts` - Vite configuration for serving frontend

- **Database & Storage**
  - `server/db.ts` - Database connection
  - `server/storage.ts` - Storage interface implementation
  - `shared/schema.ts` - Database schema and types
  - `drizzle.config.ts` - Drizzle ORM configuration

### Configuration Files

- `package.json` - Project dependencies
- `tsconfig.json` - TypeScript configuration
- `vite.config.ts` - Vite configuration
- `tailwind.config.ts` - Tailwind CSS configuration
- `theme.json` - UI theme configuration

## Latest Git Commits

```
389e1ad (HEAD -> main) Checkpoint
b3e9fa6 Fix map display option toggles
07673c7 Enhance map display with toll information and customizable settings
aa3e73e Add rest area information to route planning
c59a476 Fix overlapping weather data markers
```

## Download Instructions

The easiest way to save your project from Replit:

1. From the Files panel: Find the "Download as ZIP" option (may be under a menu)
2. Alternatively: Use the ZIP file we created at `/tmp/weathertrip_export.zip`

For GitHub upload:

1. Create a new repository at [github.com/new](https://github.com/new)
2. Follow GitHub's instructions for uploading existing code