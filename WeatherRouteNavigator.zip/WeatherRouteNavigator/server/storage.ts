import { trips, users, weatherPoints, type Trip, type User, type InsertUser, type InsertTrip, type WeatherPoint, type InsertWeatherPoint, type TripWithWeather, type RouteInfo, type WeatherForecast } from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Trip methods
  getTrip(id: number): Promise<Trip | undefined>;
  getTripWithWeather(id: number): Promise<TripWithWeather | undefined>;
  getRecentTrips(userId?: number, limit?: number): Promise<Trip[]>;
  createTrip(trip: InsertTrip): Promise<Trip>;
  
  // Weather point methods
  getWeatherPoints(tripId: number): Promise<WeatherPoint[]>;
  createWeatherPoint(weatherPoint: InsertWeatherPoint): Promise<WeatherPoint>;
  
  // Save complete trip with weather points
  saveTripWithWeather(
    trip: Omit<InsertTrip, "id">, 
    weatherForecasts: Omit<InsertWeatherPoint, "id" | "tripId">[]
  ): Promise<TripWithWeather>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  // Trip methods
  async getTrip(id: number): Promise<Trip | undefined> {
    const [trip] = await db.select().from(trips).where(eq(trips.id, id));
    return trip;
  }
  
  async getTripWithWeather(id: number): Promise<TripWithWeather | undefined> {
    const [trip] = await db.select().from(trips).where(eq(trips.id, id));
    if (!trip) return undefined;
    
    const weatherData = await this.getWeatherPoints(id);
    return {
      ...trip,
      weatherPoints: weatherData
    };
  }
  
  async getRecentTrips(userId?: number, limit = 5): Promise<Trip[]> {
    if (userId) {
      return await db.select()
        .from(trips)
        .where(eq(trips.userId, userId))
        .orderBy(desc(trips.createdAt))
        .limit(limit);
    } else {
      return await db.select()
        .from(trips)
        .orderBy(desc(trips.createdAt))
        .limit(limit);
    }
  }
  
  async createTrip(insertTrip: InsertTrip): Promise<Trip> {
    const [trip] = await db.insert(trips).values(insertTrip).returning();
    return trip;
  }
  
  // Weather point methods
  async getWeatherPoints(tripId: number): Promise<WeatherPoint[]> {
    return await db.select().from(weatherPoints).where(eq(weatherPoints.tripId, tripId));
  }
  
  async createWeatherPoint(insertWeatherPoint: InsertWeatherPoint): Promise<WeatherPoint> {
    const [weatherPoint] = await db.insert(weatherPoints).values(insertWeatherPoint).returning();
    return weatherPoint;
  }
  
  // Save complete trip with weather points
  async saveTripWithWeather(
    trip: Omit<InsertTrip, "id">, 
    weatherForecasts: Omit<InsertWeatherPoint, "id" | "tripId">[]
  ): Promise<TripWithWeather> {
    // Ensure trip has all required fields with correct types
    const tripData = {
      ...trip,
      userId: trip.userId ?? null, 
      distance: trip.distance ?? null,
      duration: trip.duration ?? null
    };
    
    // Create trip
    const [newTrip] = await db.insert(trips).values(tripData).returning();
    
    // Create weather points with proper tripId assignment
    const weatherPointsWithTripId = weatherForecasts.map(forecast => ({
      ...forecast,
      tripId: newTrip.id // This ensures tripId is not undefined
    }));
    
    const savedWeatherPoints = await db.insert(weatherPoints)
      .values(weatherPointsWithTripId)
      .returning();
    
    return {
      ...newTrip,
      weatherPoints: savedWeatherPoints
    };
  }
}

export const storage = new DatabaseStorage();
