import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const MODEL = "gpt-4o";

// Initialize the OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || "",
});

// Helper function to safely parse JSON
function safeJsonParse(jsonString: string | null): any {
  if (!jsonString) return {};
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    console.error("Failed to parse JSON response:", e);
    return {};
  }
}

export async function getRouteRecommendation(
  start: string, 
  end: string, 
  weatherData: any, 
  preferences: any
) {
  try {
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        {
          role: "system",
          content: "You are an AI route planning assistant that specializes in weather-optimized travel routes."
        },
        {
          role: "user",
          content: `I'm planning a trip from ${start} to ${end}. 
          Here's the weather forecast along potential routes: ${JSON.stringify(weatherData)}. 
          My preferences are: ${JSON.stringify(preferences)}. 
          Suggest the optimal route with timing to avoid adverse weather, explaining your reasoning.`
        }
      ],
      response_format: { type: "json_object" },
    });

    return safeJsonParse(response.choices[0].message.content);
  } catch (error) {
    console.error("Error getting route recommendation:", error);
    throw new Error("Failed to get AI route recommendation");
  }
}

export async function assessWeatherRisks(
  route: any, 
  weatherData: any
) {
  try {
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        {
          role: "system",
          content: "You are an AI weather risk analyst specializing in travel safety."
        },
        {
          role: "user",
          content: `Analyze the weather risks along this route: ${JSON.stringify(route)}
          with the following weather data: ${JSON.stringify(weatherData)}.
          Identify high-risk segments, explain the risks, and recommend safety precautions or alternate times.`
        }
      ],
      response_format: { type: "json_object" },
    });

    return safeJsonParse(response.choices[0].message.content);
  } catch (error) {
    console.error("Error assessing weather risks:", error);
    throw new Error("Failed to assess weather risks");
  }
}

export async function getTripPlanningAssistance(
  tripDetails: any, 
  weatherData: any
) {
  try {
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        {
          role: "system",
          content: "You are an AI trip planning assistant specializing in weather-optimized travel plans."
        },
        {
          role: "user",
          content: `Help me plan a trip with these details: ${JSON.stringify(tripDetails)}.
          The weather forecast is: ${JSON.stringify(weatherData)}.
          Create a detailed day-by-day itinerary optimized for weather conditions, suggesting indoor activities during bad weather and outdoor activities during good weather.`
        }
      ],
      response_format: { type: "json_object" },
    });

    return safeJsonParse(response.choices[0].message.content);
  } catch (error) {
    console.error("Error getting trip planning assistance:", error);
    throw new Error("Failed to get trip planning assistance");
  }
}

export async function processNaturalLanguageQuery(query: string) {
  try {
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        {
          role: "system",
          content: "You are an AI travel assistant that processes natural language queries about routes and weather. Return your response in JSON format."
        },
        {
          role: "user",
          content: `Parse this travel query and extract structured information in JSON format: "${query}"
          Extract locations, dates, transportation preferences, and any special requirements.
          Response should be valid JSON with the following structure:
          {
            "startLocation": "string or null",
            "endLocation": "string or null",
            "startDate": "YYYY-MM-DD or null",
            "endDate": "YYYY-MM-DD or null",
            "transportMode": "driving|transit|cycling|flight or null",
            "specialRequirements": ["string"],
            "parsed": boolean,
            "confidence": number
          }`
        }
      ],
      response_format: { type: "json_object" },
    });

    return safeJsonParse(response.choices[0].message.content);
  } catch (error) {
    console.error("Error processing natural language query:", error);
    throw new Error("Failed to process natural language query");
  }
}

export async function getPersonalizedRecommendations(
  userProfile: any, 
  pastTrips: any,
  weatherData: any
) {
  try {
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        {
          role: "system",
          content: "You are an AI travel recommendation system that personalizes suggestions based on user history and preferences."
        },
        {
          role: "user",
          content: `Generate personalized travel recommendations for this user profile: ${JSON.stringify(userProfile)}.
          Their past trips were: ${JSON.stringify(pastTrips)}.
          Current weather forecasts: ${JSON.stringify(weatherData)}.
          Suggest 3-5 personalized recommendations that match their preferences and take weather conditions into account.`
        }
      ],
      response_format: { type: "json_object" },
    });

    return safeJsonParse(response.choices[0].message.content);
  } catch (error) {
    console.error("Error getting personalized recommendations:", error);
    throw new Error("Failed to get personalized recommendations");
  }
}

export async function getWeatherBasedDetours(
  originalRoute: any, 
  weatherData: any
) {
  try {
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        {
          role: "system",
          content: "You are an AI detour specialist that suggests alternative routes based on weather conditions."
        },
        {
          role: "user",
          content: `My original route is: ${JSON.stringify(originalRoute)}.
          The weather forecast along this route is: ${JSON.stringify(weatherData)}.
          Suggest potential detours or alternative routes to avoid bad weather, including estimated time impacts.`
        }
      ],
      response_format: { type: "json_object" },
    });

    return safeJsonParse(response.choices[0].message.content);
  } catch (error) {
    console.error("Error getting weather-based detours:", error);
    throw new Error("Failed to get weather-based detours");
  }
}

export async function predictWeatherAdjustedTravelTime(
  route: any, 
  weatherData: any,
  transportMode: string
) {
  try {
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        {
          role: "system",
          content: "You are an AI travel time prediction specialist that accounts for weather impacts on various transportation modes."
        },
        {
          role: "user",
          content: `Predict the travel time for this route: ${JSON.stringify(route)},
          using transportation mode: ${transportMode},
          with this weather forecast: ${JSON.stringify(weatherData)}.
          Provide a detailed breakdown of how weather conditions will affect travel time compared to normal conditions.`
        }
      ],
      response_format: { type: "json_object" },
    });

    return safeJsonParse(response.choices[0].message.content);
  } catch (error) {
    console.error("Error predicting weather-adjusted travel time:", error);
    throw new Error("Failed to predict weather-adjusted travel time");
  }
}