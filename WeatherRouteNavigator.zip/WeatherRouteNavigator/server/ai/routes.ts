import { Request, Response } from "express";
import {
  getRouteRecommendation,
  assessWeatherRisks,
  getTripPlanningAssistance,
  processNaturalLanguageQuery,
  getPersonalizedRecommendations,
  getWeatherBasedDetours,
  predictWeatherAdjustedTravelTime
} from "./openai-client";
import { storage } from "../storage";

// 1. Smart Route Recommendations
export async function handleRouteRecommendation(req: Request, res: Response) {
  try {
    const { start, end, weatherData, preferences } = req.body;
    
    if (!start || !end || !weatherData) {
      return res.status(400).json({ error: "Missing required parameters" });
    }
    
    const recommendation = await getRouteRecommendation(start, end, weatherData, preferences);
    res.json({ recommendation });
  } catch (error) {
    console.error("Route recommendation error:", error);
    res.status(500).json({ error: "Failed to generate route recommendation" });
  }
}

// 2. Weather Risk Assessment
export async function handleWeatherRiskAssessment(req: Request, res: Response) {
  try {
    const { route, weatherData } = req.body;
    
    if (!route || !weatherData) {
      return res.status(400).json({ error: "Missing required parameters" });
    }
    
    const riskAssessment = await assessWeatherRisks(route, weatherData);
    res.json({ riskAssessment });
  } catch (error) {
    console.error("Weather risk assessment error:", error);
    res.status(500).json({ error: "Failed to assess weather risks" });
  }
}

// 3. Trip Planning Assistant
export async function handleTripPlanningAssistance(req: Request, res: Response) {
  try {
    const { tripDetails, weatherData } = req.body;
    
    if (!tripDetails || !weatherData) {
      return res.status(400).json({ error: "Missing required parameters" });
    }
    
    const tripPlan = await getTripPlanningAssistance(tripDetails, weatherData);
    res.json({ tripPlan });
  } catch (error) {
    console.error("Trip planning assistance error:", error);
    res.status(500).json({ error: "Failed to generate trip planning assistance" });
  }
}

// 4. Natural Language Processing
export async function handleNaturalLanguageQuery(req: Request, res: Response) {
  try {
    const { query } = req.body;
    
    if (!query) {
      return res.status(400).json({ error: "Missing query parameter" });
    }
    
    const parsedQuery = await processNaturalLanguageQuery(query);
    res.json({ parsedQuery });
  } catch (error) {
    console.error("Natural language query error:", error);
    res.status(500).json({ error: "Failed to process natural language query" });
  }
}

// 5. Personalized Travel Recommendations
export async function handlePersonalizedRecommendations(req: Request, res: Response) {
  try {
    const { userProfile, pastTrips, weatherData } = req.body;
    
    if (!userProfile || !weatherData) {
      return res.status(400).json({ error: "Missing required parameters" });
    }
    
    // If pastTrips not provided, try to fetch from database if userId is available
    let tripsData = pastTrips;
    if (!tripsData && userProfile.userId) {
      try {
        tripsData = await storage.getRecentTrips(userProfile.userId, 10);
      } catch (error) {
        console.error("Error fetching past trips:", error);
        // Continue without past trips data
        tripsData = [];
      }
    }
    
    const recommendations = await getPersonalizedRecommendations(userProfile, tripsData || [], weatherData);
    res.json({ recommendations });
  } catch (error) {
    console.error("Personalized recommendations error:", error);
    res.status(500).json({ error: "Failed to generate personalized recommendations" });
  }
}

// 6. Weather-based Detour Suggestions
export async function handleWeatherBasedDetours(req: Request, res: Response) {
  try {
    const { originalRoute, weatherData } = req.body;
    
    if (!originalRoute || !weatherData) {
      return res.status(400).json({ error: "Missing required parameters" });
    }
    
    const detours = await getWeatherBasedDetours(originalRoute, weatherData);
    res.json({ detours });
  } catch (error) {
    console.error("Weather-based detours error:", error);
    res.status(500).json({ error: "Failed to generate weather-based detours" });
  }
}

// 7. Weather-adjusted Travel Time Prediction
export async function handleWeatherAdjustedTravelTime(req: Request, res: Response) {
  try {
    const { route, weatherData, transportMode } = req.body;
    
    if (!route || !weatherData || !transportMode) {
      return res.status(400).json({ error: "Missing required parameters" });
    }
    
    const travelTimePrediction = await predictWeatherAdjustedTravelTime(route, weatherData, transportMode);
    res.json({ travelTimePrediction });
  } catch (error) {
    console.error("Weather-adjusted travel time prediction error:", error);
    res.status(500).json({ error: "Failed to predict weather-adjusted travel time" });
  }
}