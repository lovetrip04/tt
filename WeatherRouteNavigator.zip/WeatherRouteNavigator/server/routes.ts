import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import axios from "axios";
import { insertTripSchema, insertWeatherPointSchema } from "@shared/schema";
import { z } from "zod";
import {
  handleRouteRecommendation,
  handleWeatherRiskAssessment,
  handleTripPlanningAssistance,
  handleNaturalLanguageQuery,
  handlePersonalizedRecommendations,
  handleWeatherBasedDetours,
  handleWeatherAdjustedTravelTime
} from "./ai/routes";

// Using all open source alternatives without API keys

export async function registerRoutes(app: Express): Promise<Server> {
  // put application routes here
  // prefix all routes with /api

  // Get directions and route between two points
  app.get("/api/directions", async (req, res) => {
    try {
      const { start, end } = req.query;
      
      if (!start || !end) {
        return res.status(400).json({ message: "Start and end locations are required" });
      }
      
      // Using OpenStreetMap Routing Machine (OSRM) for directions
      const [startLng, startLat] = (start as string).split(',').map(parseFloat);
      const [endLng, endLat] = (end as string).split(',').map(parseFloat);
      
      const response = await axios.get(
        `https://router.project-osrm.org/route/v1/driving/${startLng},${startLat};${endLng},${endLat}`,
        {
          params: {
            overview: "full",
            geometries: "geojson",
            steps: true
          }
        }
      );
      
      if (!response.data || !response.data.routes || !response.data.routes.length) {
        return res.status(404).json({ message: "No route found" });
      }
      
      const route = response.data.routes[0];
      const coordinates = route.geometry.coordinates.map(([lng, lat]: [number, number]) => ({ lat, lng }));
      
      // Calculate number of stops (this is simplified, in a real app we'd use more complex logic)
      const distance = route.distance;
      const duration = route.duration;
      const stops = Math.floor(duration / 7200); // Stops every 2 hours of driving
      
      const routeInfo = {
        distance: `${Math.round(distance / 1609.34)} miles`, // Convert meters to miles
        duration: formatDuration(duration),
        path: coordinates,
        stops: `${stops} stops along route`
      };
      
      res.json(routeInfo);
    } catch (error) {
      console.error("Directions API error:", error);
      res.status(500).json({ message: "Failed to get directions" });
    }
  });
  
  // Get geocoding for a location name
  app.get("/api/geocode", async (req, res) => {
    try {
      const { location } = req.query;
      
      if (!location) {
        return res.status(400).json({ message: "Location is required" });
      }
      
      // Using OpenStreetMap Nominatim for geocoding
      const response = await axios.get(
        `https://nominatim.openstreetmap.org/search`,
        {
          params: {
            q: location,
            format: 'json',
            limit: 1
          },
          headers: {
            'User-Agent': 'WeatherTrip Application' // Required by Nominatim ToS
          }
        }
      );
      
      if (!response.data || response.data.length === 0) {
        return res.status(404).json({ message: "Location not found" });
      }
      
      const result = response.data[0];
      
      res.json({
        lat: parseFloat(result.lat),
        lng: parseFloat(result.lon),
        placeName: result.display_name
      });
    } catch (error) {
      console.error("Geocoding API error:", error);
      res.status(500).json({ message: "Failed to geocode location" });
    }
  });
  
  // Get weather forecast for a location and date range
  app.get("/api/weather", async (req, res) => {
    try {
      const { lat, lng, startDate } = req.query;
      
      if (!lat || !lng) {
        return res.status(400).json({ message: "Latitude and longitude are required" });
      }
      
      // Call Open-Meteo API for forecast (completely free and open source)
      const response = await axios.get(
        `https://api.open-meteo.com/v1/forecast`,
        {
          params: {
            latitude: lat,
            longitude: lng,
            daily: [
              'temperature_2m_max', 
              'temperature_2m_min', 
              'apparent_temperature_max',
              'precipitation_sum',
              'precipitation_probability_max',
              'windspeed_10m_max'
            ],
            temperature_unit: 'fahrenheit',
            windspeed_unit: 'mph',
            timezone: 'auto',
            forecast_days: 10
          }
        }
      );
      
      if (!response.data || !response.data.daily) {
        return res.status(404).json({ message: "Weather data not found" });
      }
      
      // Process the forecast data
      const forecasts = [];
      const daily = response.data.daily;
      
      for (let i = 0; i < daily.time.length; i++) {
        // Determine weather condition based on precipitation
        let condition = 'Clear';
        let icon = 'sun';
        
        const precipProb = daily.precipitation_probability_max[i];
        if (precipProb > 70) {
          condition = 'Rain';
          icon = 'cloud-rain';
        } else if (precipProb > 30) {
          condition = 'Cloudy with chance of rain';
          icon = 'cloud-drizzle';
        } else if (precipProb > 10) {
          condition = 'Mostly Cloudy';
          icon = 'cloud';
        } else if (precipProb > 0) {
          condition = 'Partly Cloudy';
          icon = 'cloud-sun';
        }
        
        const avgTemp = (daily.temperature_2m_max[i] + daily.temperature_2m_min[i]) / 2;
        
        forecasts.push({
          date: daily.time[i],
          temperature: Math.round(avgTemp) + "°F",
          condition: condition,
          icon: icon,
          highTemp: Math.round(daily.temperature_2m_max[i]) + "°F",
          lowTemp: Math.round(daily.temperature_2m_min[i]) + "°F",
          windSpeed: Math.round(daily.windspeed_10m_max[i]) + " mph",
          lat,
          lng
        });
      }
      
      res.json(forecasts);
    } catch (error) {
      console.error("Weather API error:", error);
      res.status(500).json({ message: "Failed to get weather forecast" });
    }
  });
  
  // Get weather forecast for multiple points along a route
  app.post("/api/route-weather", async (req, res) => {
    try {
      const { 
        startLocation, 
        endLocation, 
        startDate = new Date().toISOString().split("T")[0], 
        endDate, 
        waypoints = [],
        transportMode = "driving"
      } = req.body;
      
      if (!startLocation || !endLocation) {
        return res.status(400).json({ message: "Start and end locations are required" });
      }
      
      // Geocode start and end locations
      const startGeocode = await getGeocode(startLocation);
      const endGeocode = await getGeocode(endLocation);
      
      if (!startGeocode || !endGeocode) {
        return res.status(404).json({ message: "Could not geocode one or more locations" });
      }
      
      // Get route
      const route = await getRoute(
        `${startGeocode.lng},${startGeocode.lat}`, 
        `${endGeocode.lng},${endGeocode.lat}`,
        transportMode
      );
      
      if (!route) {
        return res.status(404).json({ message: "Could not find route" });
      }
      
      // Sample points along the route
      const points = sampleRoutePoints(route.path, 5); // Get 5 points along the route including start and end
      
      // Get weather for each point
      const weatherPromises = points.map(async (point, index) => {
        let location;
        if (index === 0) {
          location = startLocation;
        } else if (index === points.length - 1) {
          location = endLocation;
        } else {
          // Reverse geocode intermediate points using OpenStreetMap Nominatim
          const response = await axios.get(
            `https://nominatim.openstreetmap.org/reverse`,
            {
              params: {
                lat: point.lat,
                lon: point.lng,
                format: 'json',
                zoom: 10 // Appropriate zoom level for city/town
              },
              headers: {
                'User-Agent': 'WeatherTrip Application' // Required by Nominatim ToS
              }
            }
          );
          
          if (response.data && response.data.display_name) {
            const placeName = response.data.display_name;
            const parts = placeName.split(', ');
            // Try to get city or town name, usually in first few parts
            location = parts.length > 2 ? parts[1] : parts[0];
          } else {
            location = `Point ${index}`;
          }
        }
        
        // Get weather forecast for this point using Open-Meteo
        const weatherResponse = await axios.get(
          `https://api.open-meteo.com/v1/forecast`,
          {
            params: {
              latitude: point.lat,
              longitude: point.lng,
              daily: [
                'temperature_2m_max', 
                'temperature_2m_min', 
                'apparent_temperature_max',
                'precipitation_sum',
                'precipitation_probability_max',
                'windspeed_10m_max'
              ],
              hourly: [
                'temperature_2m',
                'weathercode',
                'precipitation_probability'
              ],
              temperature_unit: 'fahrenheit',
              windspeed_unit: 'mph',
              timezone: 'auto',
              forecast_days: 10
            }
          }
        );
        
        if (!weatherResponse.data || !weatherResponse.data.daily) {
          throw new Error("Weather data not found");
        }
        
        // Process the forecast data
        const forecasts = [];
        const daily = weatherResponse.data.daily;
        
        for (let i = 0; i < daily.time.length; i++) {
          // Determine weather condition based on precipitation
          let condition = 'Clear';
          let icon = 'sun';
          
          const precipProb = daily.precipitation_probability_max[i];
          if (precipProb > 70) {
            condition = 'Rain';
            icon = 'cloud-rain';
          } else if (precipProb > 30) {
            condition = 'Cloudy with chance of rain';
            icon = 'cloud-drizzle';
          } else if (precipProb > 10) {
            condition = 'Mostly Cloudy';
            icon = 'cloud';
          } else if (precipProb > 0) {
            condition = 'Partly Cloudy';
            icon = 'cloud-sun';
          }
          
          const avgTemp = (daily.temperature_2m_max[i] + daily.temperature_2m_min[i]) / 2;
          
          // Process hourly data for the current day to get time period forecasts
          const currentDate = daily.time[i];
          const hourly = weatherResponse.data.hourly;
          const timeOfDayForecasts: {
            morningWeather?: any;
            afternoonWeather?: any;
            eveningWeather?: any;
            nightWeather?: any;
          } = {};
          
          if (hourly && hourly.time) {
            // Filter hourly data for the current day
            const currentDayHours = hourly.time
              .map((time: string, idx: number) => ({
                time,
                temp: hourly.temperature_2m[idx],
                code: hourly.weathercode[idx],
                precip: hourly.precipitation_probability[idx]
              }))
              .filter((hour: any) => hour.time.startsWith(currentDate));
            
            if (currentDayHours.length > 0) {
              // Define time periods (6am-12pm, 12pm-6pm, 6pm-12am, 12am-6am)
              const morningHours = currentDayHours.filter((h: any) => {
                const hour = parseInt(h.time.split('T')[1].split(':')[0]);
                return hour >= 6 && hour < 12;
              });
              
              const afternoonHours = currentDayHours.filter((h: any) => {
                const hour = parseInt(h.time.split('T')[1].split(':')[0]);
                return hour >= 12 && hour < 18;
              });
              
              const eveningHours = currentDayHours.filter((h: any) => {
                const hour = parseInt(h.time.split('T')[1].split(':')[0]);
                return hour >= 18 && hour < 24;
              });
              
              const nightHours = currentDayHours.filter((h: any) => {
                const hour = parseInt(h.time.split('T')[1].split(':')[0]);
                return hour >= 0 && hour < 6;
              });
              
              // Create time period forecasts
              const createTimePeriodForecast = (hours: any[]) => {
                if (hours.length === 0) return null;
                
                // Average temperature
                const avgTemp = hours.reduce((sum, h) => sum + h.temp, 0) / hours.length;
                
                // Max precipitation probability
                const maxPrecip = Math.max(...hours.map(h => h.precip));
                
                // Determine condition based on weathercode and precipitation
                let condition = 'Clear';
                let icon = 'sun';
                
                if (maxPrecip > 70) {
                  condition = 'Rain';
                  icon = 'cloud-rain';
                } else if (maxPrecip > 30) {
                  condition = 'Chance of rain';
                  icon = 'cloud-drizzle';
                } else if (maxPrecip > 10) {
                  condition = 'Mostly Cloudy';
                  icon = 'cloud';
                } else if (maxPrecip > 0) {
                  condition = 'Partly Cloudy';
                  icon = 'cloud-sun';
                }
                
                return {
                  temperature: Math.round(avgTemp) + "°F",
                  condition,
                  icon,
                  precipitationProbability: maxPrecip + "%"
                };
              };
              
              timeOfDayForecasts.morningWeather = createTimePeriodForecast(morningHours);
              timeOfDayForecasts.afternoonWeather = createTimePeriodForecast(afternoonHours);
              timeOfDayForecasts.eveningWeather = createTimePeriodForecast(eveningHours);
              timeOfDayForecasts.nightWeather = createTimePeriodForecast(nightHours);
            }
          }
          
          forecasts.push({
            location,
            date: daily.time[i],
            temperature: Math.round(avgTemp) + "°F",
            condition: condition,
            icon: icon,
            highTemp: Math.round(daily.temperature_2m_max[i]) + "°F",
            lowTemp: Math.round(daily.temperature_2m_min[i]) + "°F",
            windSpeed: Math.round(daily.windspeed_10m_max[i]) + " mph",
            lat: point.lat.toString(),  // Convert to string to match schema
            lng: point.lng.toString(),  // Convert to string to match schema
            morningWeather: timeOfDayForecasts.morningWeather,
            afternoonWeather: timeOfDayForecasts.afternoonWeather,
            eveningWeather: timeOfDayForecasts.eveningWeather,
            nightWeather: timeOfDayForecasts.nightWeather
          });
        }
        
        return forecasts;
      });
      
      try {
        const weatherResults = await Promise.all(weatherPromises);
        
        // Flatten and organize by date
        const allForecasts = weatherResults.flat();
        
        // Group by date
        const forecastsByDate: Record<string, any[]> = {};
        allForecasts.forEach(forecast => {
          if (!forecastsByDate[forecast.date]) {
            forecastsByDate[forecast.date] = [];
          }
          forecastsByDate[forecast.date].push(forecast);
        });
        
        // Save trip to storage
        const newTrip = {
          userId: null,
          startLocation,
          endLocation,
          startDate,
          endDate: endDate || startDate,
          distance: route.distance,
          duration: route.duration,
          createdAt: new Date().toISOString()
        };
        
        // Ensure weather points match the expected schema
        const weatherPointsToSave = allForecasts.map(forecast => ({
          location: forecast.location,
          date: forecast.date,
          temperature: forecast.temperature,
          condition: forecast.condition,
          highTemp: forecast.highTemp,
          lowTemp: forecast.lowTemp,
          windSpeed: forecast.windSpeed,
          lat: forecast.lat,
          lng: forecast.lng
        }));
        
        // Save trip and weather data
        const savedTrip = await storage.saveTripWithWeather(
          newTrip,
          weatherPointsToSave
        );
        
        res.json({
          trip: {
            id: savedTrip.id,
            startLocation,
            endLocation,
            startDate,
            endDate: endDate || startDate,
            distance: route.distance,
            duration: route.duration,
            stops: route.stops,
            transportMode: route.transportMode || transportMode
          },
          route: {
            path: route.path,
            restAreas: route.restAreas || [],
            tolls: route.tolls || [],
            transportMode: route.transportMode || transportMode
          },
          forecasts: forecastsByDate
        });
      } catch (error) {
        console.error("Weather processing error:", error);
        res.status(500).json({ message: "Failed to process weather data" });
      }
    } catch (error) {
      console.error("Route weather error:", error);
      res.status(500).json({ message: "Failed to get route weather" });
    }
  });
  
  // Get recent trips
  app.get("/api/trips/recent", async (req, res) => {
    try {
      const recentTrips = await storage.getRecentTrips();
      res.json(recentTrips);
    } catch (error) {
      console.error("Recent trips error:", error);
      res.status(500).json({ message: "Failed to get recent trips" });
    }
  });
  
  // Get trip by ID with weather data
  app.get("/api/trips/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const trip = await storage.getTripWithWeather(parseInt(id));
      
      if (!trip) {
        return res.status(404).json({ message: "Trip not found" });
      }
      
      res.json(trip);
    } catch (error) {
      console.error("Get trip error:", error);
      res.status(500).json({ message: "Failed to get trip" });
    }
  });
  
  // Helper functions
  async function getGeocode(location: string) {
    try {
      // Format and clean the location string
      // Add country specification to improve results
      const formattedLocation = location.includes("USA") || location.includes("US") 
        ? location 
        : `${location}, USA`;
        
      console.log("Geocoding location:", formattedLocation);
        
      // Using OpenStreetMap Nominatim for geocoding
      const response = await axios.get(
        `https://nominatim.openstreetmap.org/search`,
        {
          params: {
            q: formattedLocation,
            format: 'json',
            limit: 1,
            countrycodes: 'us', // Restrict to US results
            addressdetails: 1,  // Get detailed address info
          },
          headers: {
            'User-Agent': 'WeatherTrip Application' // Required by Nominatim ToS
          }
        }
      );
      
      if (!response.data || response.data.length === 0) {
        console.log("No geocoding results found for:", formattedLocation);
        return null;
      }
      
      const result = response.data[0];
      console.log("Geocoding result:", result);
      
      return { 
        lat: parseFloat(result.lat), 
        lng: parseFloat(result.lon), 
        placeName: result.display_name 
      };
    } catch (error) {
      console.error("Geocoding error:", error);
      return null;
    }
  }
  
  // Helper function to get amenities for a rest area
  function getRandomAmenities() {
    const allAmenities = [
      "Restrooms", "Food", "Fuel", "EV Charging", "WiFi", 
      "Picnic Area", "Vending Machines", "Information", "Playground"
    ];
    
    // Randomly select 3-5 amenities
    const count = Math.floor(Math.random() * 3) + 3;
    const selectedAmenities = [];
    
    // Copy array to avoid modifying original
    const availableAmenities = [...allAmenities];
    
    for (let i = 0; i < count; i++) {
      if (availableAmenities.length === 0) break;
      const index = Math.floor(Math.random() * availableAmenities.length);
      selectedAmenities.push(availableAmenities[index]);
      availableAmenities.splice(index, 1);
    }
    
    return selectedAmenities;
  }
  
  async function findTransitStations(coordinates: Array<{lat: number, lng: number}>, totalDistance: number) {
    // Generate train stations and bus stops along the route
    const stations = [];
    const busStops = [];
    
    // For long routes, add major train stations
    if (totalDistance > 80000) { // 50+ miles
      // Add train stations roughly every 80-120 miles
      const stationInterval = Math.min(160000, totalDistance / 3); // km in meters, max 100 miles or 1/3 of route
      let currentDistance = stationInterval / 2; // Start at half interval to place first station
      
      while (currentDistance < totalDistance - stationInterval/2) { // Leave space at the end
        const percentage = currentDistance / totalDistance;
        const pointIndex = Math.floor(percentage * coordinates.length);
        
        if (pointIndex > 0 && pointIndex < coordinates.length - 1) {
          const point = coordinates[pointIndex];
          const placeName = await getNearbyPlace(point.lat, point.lng);
          
          stations.push({
            lat: point.lat,
            lng: point.lng,
            name: `${placeName} Train Station`,
            type: "train",
            distanceFromStart: `${Math.round(currentDistance / 1609.34)} miles from start`
          });
        }
        
        currentDistance += stationInterval;
      }
      
      // Add bus stops between train stations
      if (stations.length >= 2) {
        for (let i = 0; i < stations.length - 1; i++) {
          const startStation = stations[i];
          const endStation = stations[i + 1];
          
          // Add 1-2 bus stops between stations
          const numBusStops = 1 + Math.floor(Math.random() * 2);
          
          for (let j = 1; j <= numBusStops; j++) {
            const fraction = j / (numBusStops + 1);
            const busLat = startStation.lat + fraction * (endStation.lat - startStation.lat);
            const busLng = startStation.lng + fraction * (endStation.lng - startStation.lng);
            
            const busPlaceName = await getNearbyPlace(busLat, busLng);
            busStops.push({
              lat: busLat,
              lng: busLng,
              name: `${busPlaceName} Bus Stop`,
              type: "bus"
            });
          }
        }
      }
    } else {
      // For shorter routes, just add bus stops
      const numBusStops = Math.min(5, Math.max(2, Math.floor(totalDistance / 16000))); // ~1 per 10 miles, min 2, max 5
      
      for (let i = 1; i <= numBusStops; i++) {
        const percentage = i / (numBusStops + 1);
        const pointIndex = Math.floor(percentage * coordinates.length);
        
        if (pointIndex > 0 && pointIndex < coordinates.length - 1) {
          const point = coordinates[pointIndex];
          const placeName = await getNearbyPlace(point.lat, point.lng);
          
          busStops.push({
            lat: point.lat,
            lng: point.lng,
            name: `${placeName} Bus Stop`,
            type: "bus"
          });
        }
      }
    }
    
    return { stations, busStops };
  }
  
  // Get nearby places along a route using Nominatim
  async function getNearbyPlace(lat: number, lng: number) {
    try {
      const response = await axios.get('https://nominatim.openstreetmap.org/reverse', {
        params: {
          lat,
          lon: lng,
          format: 'json',
          zoom: 10, // town level
          addressdetails: 1
        },
        headers: {
          'User-Agent': 'WeatherTrip Application'
        }
      });
      
      if (response.data && response.data.address) {
        const { city, town, village, county, hamlet } = response.data.address;
        return city || town || village || county || hamlet || 'Rest Area';
      }
      return 'Rest Area';
    } catch (error) {
      console.error("Error getting nearby place:", error);
      return 'Rest Area';
    }
  }
  
  async function getRoute(start: string, end: string, transportMode: string = "driving") {
    try {
      // Parse start and end coordinates
      const [startLng, startLat] = start.split(',').map(parseFloat);
      const [endLng, endLat] = end.split(',').map(parseFloat);
      
      // Map our transport modes to OSRM profile values
      const osrmProfile = {
        "driving": "car",
        "flight": "foot", // For flights, we use direct 'as-the-crow-flies' path, which foot profile can simulate
        "cycling": "bike",
        "transit": "car" // We'll handle transit differently after getting the base route
      }[transportMode] || "car";
      
      // For flight mode, we'll use a direct path with a slight arc to simulate flight path
      let coordinates = [];
      let route;
      let distance = 0;
      let duration = 0;
      
      if (transportMode === "flight") {
        // Calculate direct distance (as crow flies)
        const R = 6371e3; // Earth's radius in meters
        const φ1 = startLat * Math.PI/180;
        const φ2 = endLat * Math.PI/180;
        const Δφ = (endLat-startLat) * Math.PI/180;
        const Δλ = (endLng-startLng) * Math.PI/180;
        
        const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
                  Math.cos(φ1) * Math.cos(φ2) *
                  Math.sin(Δλ/2) * Math.sin(Δλ/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        
        distance = R * c; // Distance in meters
        
        // Generate arc path for flight (start, middle with curve, end)
        const numPoints = 20; // Number of points in the path
        coordinates = [];
        
        for (let i = 0; i < numPoints; i++) {
          const t = i / (numPoints - 1);
          const lng = startLng + t * (endLng - startLng);
          const lat = startLat + t * (endLat - startLat);
          
          // Add slight arc to middle of the path - higher in the middle
          const arc = Math.sin(Math.PI * t) * 0.05; // Maximum 5% of direct path as arc height
          const latAdjusted = lat + arc * (endLat - startLat);
          
          coordinates.push({ lat: latAdjusted, lng });
        }
        
        // Estimate flight duration - average commercial flight speed ~500 mph
        const flightSpeedMPS = 224; // meters per second (~500 mph)
        duration = distance / flightSpeedMPS + 2400; // Adding 40 minutes for takeoff/landing procedures
      } else {
        // Using OpenStreetMap Routing Machine (OSRM) for routing
        const response = await axios.get(
          `https://router.project-osrm.org/route/v1/${osrmProfile}/${startLng},${startLat};${endLng},${endLat}`,
          {
            params: {
              overview: "full",
              geometries: "geojson",
              steps: true,
              annotations: true // Get detailed annotations for toll information
            }
          }
        );
        
        if (!response.data || !response.data.routes || !response.data.routes.length) {
          return null;
        }
        
        route = response.data.routes[0];
        
        // OSRM returns a GeoJSON LineString in the geometry property
        coordinates = route.geometry.coordinates.map(([lng, lat]: [number, number]) => ({ lat, lng }));
        distance = route.distance;
        duration = route.duration;
      }
      
      // Calculate stops based on duration
      const stops = Math.floor(duration / 7200); // Stops every 2 hours of travel
      
      // Generate rest areas along the route
      const restAreas = [];
      
      if (transportMode === "flight") {
        // For flights, we'll use connection airports if the flight is long enough
        if (distance > 2000000) { // Only for flights longer than ~1200 miles
          // Add one connection in the middle
          const midPoint = coordinates[Math.floor(coordinates.length / 2)];
          const placeName = await getNearbyPlace(midPoint.lat, midPoint.lng);
          
          restAreas.push({
            lat: midPoint.lat,
            lng: midPoint.lng,
            name: `${placeName} Connection`,
            amenities: ["Restaurants", "Shopping", "Wi-Fi", "Lounges", "Charging Stations"],
            distanceFromStart: `${Math.round(distance * 0.5 / 1609.34)} miles from departure`,
            timeFromStart: formatDuration(duration * 0.5) // Half the total flight time
          });
        }
      }
      else if (coordinates.length > 0 && stops > 0) {
        // Place rest stops along the route at regular intervals based on driving time
        for (let i = 1; i <= stops; i++) {
          // Get position along the route based on time percentage
          const percentage = i / (stops + 1);
          const pointIndex = Math.floor(percentage * coordinates.length);
          
          if (pointIndex > 0 && pointIndex < coordinates.length - 1) {
            const point = coordinates[pointIndex];
            const distanceFromStart = Math.round(distance * percentage / 1609.34); // miles
            const timeFromStart = Math.round(duration * percentage / 60); // minutes
            
            const placeName = await getNearbyPlace(point.lat, point.lng);
            const restAreaName = `${placeName} Rest Area`;
            
            restAreas.push({
              lat: point.lat,
              lng: point.lng,
              name: restAreaName,
              amenities: getRandomAmenities(),
              distanceFromStart: `${distanceFromStart} miles from start`,
              timeFromStart: formatDuration(timeFromStart * 60) // Convert minutes back to seconds for formatter
            });
          }
        }
      }
      
      // Process steps for toll information
      const tolls = [];
      
      // For flights, we'll add airport fees instead of tolls
      if (transportMode === "flight") {
        // Add departure and arrival airport fees
        const departureAirport = await getNearbyPlace(startLat, startLng);
        const arrivalAirport = await getNearbyPlace(endLat, endLng);
        
        tolls.push({
          location: `${departureAirport} Airport`,
          cost: `$${(Math.random() * 15 + 25).toFixed(2)}`, // Departure fee $25-40
          lat: startLat,
          lng: startLng
        });
        
        tolls.push({
          location: `${arrivalAirport} Airport`,
          cost: `$${(Math.random() * 15 + 20).toFixed(2)}`, // Arrival fee $20-35
          lat: endLat,
          lng: endLng
        });
      }
      // Check route steps for toll roads for other transport modes
      else if (route && route.legs && route.legs.length > 0) {
        for (const leg of route.legs) {
          if (leg.steps) {
            for (const step of leg.steps) {
              // Check if this step has a toll road
              if (step.maneuver && 
                  step.name && 
                  (step.name.toLowerCase().includes('toll') || 
                   (step.maneuver.modifier && step.maneuver.modifier.toLowerCase().includes('toll')))) {
                const midpoint = Math.floor(step.geometry.coordinates.length / 2);
                if (midpoint < step.geometry.coordinates.length) {
                  const [lng, lat] = step.geometry.coordinates[midpoint];
                  const location = await getNearbyPlace(lat, lng);
                  
                  tolls.push({
                    location: `${location} Toll`,
                    cost: "Varies", // OSRM doesn't provide actual toll costs
                    lat,
                    lng
                  });
                }
              }
            }
          }
        }
      }
      
      // If we couldn't detect specific tolls but the route is likely to have tolls
      // we'll add estimated toll points based on route distance
      if (tolls.length === 0 && distance > 80000) { // Routes longer than 50 miles
        // Add estimated tolls every 80-120 miles on long routes
        const tollInterval = Math.floor(Math.random() * 40000) + 80000; // 80-120km in meters
        let currentDistance = tollInterval;
        
        while (currentDistance < distance) {
          const percentage = currentDistance / distance;
          const pointIndex = Math.floor(percentage * coordinates.length);
          
          if (pointIndex > 0 && pointIndex < coordinates.length - 1) {
            const point = coordinates[pointIndex];
            const placeName = await getNearbyPlace(point.lat, point.lng);
            
            tolls.push({
              location: `${placeName} Toll`,
              cost: `$${(Math.random() * 8 + 2).toFixed(2)}`, // Random cost between $2-$10
              lat: point.lat,
              lng: point.lng
            });
          }
          
          currentDistance += tollInterval;
        }
      }
      
      // Special handling for transit mode
      let transitInfo;
      if (transportMode === "transit") {
        // Find transit stations (train stations and bus stops)
        const transitPoints = await findTransitStations(coordinates, distance);
        
        // Create transit segments
        const transitSegments = [];
        let lastPoint = { lat: startLat, lng: startLng };
        let segmentStart = "Starting Location";
        
        // Add walking segment from start location to first train station if distance is short
        if (transitPoints.stations.length > 0) {
          const firstStation = transitPoints.stations[0];
          const distanceToFirstStation = distance * (Math.abs(firstStation.lat - lastPoint.lat) / Math.abs(endLat - startLat));
          
          // If the distance is short enough, walk to the first station
          if (distanceToFirstStation <= 3200) { // Less than 2 miles
            transitSegments.push({
              type: "walk",
              name: "Walking to station",
              duration: formatDuration(distanceToFirstStation / 1.4), // Walking is slower than transit
              distance: `${Math.round(distanceToFirstStation / 1609.34)} miles`,
              startLocation: segmentStart,
              endLocation: firstStation.name
            });
            
            lastPoint = { lat: firstStation.lat, lng: firstStation.lng };
            segmentStart = firstStation.name;
            
            // Skip the first station in the loop since we've already handled it
            transitPoints.stations = transitPoints.stations.slice(1);
          }
        }
        
        // Add train stations
        for (const station of transitPoints.stations) {
          transitSegments.push({
            type: "train",
            line: `Line ${Math.floor(Math.random() * 20) + 1}`,
            name: `Express Transit`,
            duration: formatDuration(duration * (Math.abs(station.lat - lastPoint.lat) / Math.abs(endLat - startLat))),
            distance: `${Math.round(distance * (Math.abs(station.lat - lastPoint.lat) / Math.abs(endLat - startLat)) / 1609.34)} miles`,
            startLocation: segmentStart,
            endLocation: station.name,
            departureTime: "Scheduled",
            arrivalTime: "Scheduled"
          });
          
          lastPoint = { lat: station.lat, lng: station.lng };
          segmentStart = station.name;
        }
        
        // Add bus stops if available
        for (const busStop of transitPoints.busStops) {
          // Calculate distance to this stop
          const distanceToBusStop = distance * (Math.abs(busStop.lat - lastPoint.lat) / Math.abs(endLat - startLat));
          
          // For very short distances (less than 0.5 miles), add a walking segment instead of bus
          if (distanceToBusStop <= 800) { // Less than 0.5 miles
            transitSegments.push({
              type: "walk",
              name: "Walking between stops",
              duration: formatDuration(distanceToBusStop / 1.4), // Walking is slower
              distance: `${Math.round(distanceToBusStop / 1609.34)} miles`,
              startLocation: segmentStart,
              endLocation: busStop.name
            });
          } else {
            transitSegments.push({
              type: "bus",
              line: `Route ${Math.floor(Math.random() * 100) + 1}`,
              name: `Local Bus`,
              duration: formatDuration(duration * (Math.abs(busStop.lat - lastPoint.lat) / Math.abs(endLat - startLat))),
              distance: `${Math.round(distanceToBusStop / 1609.34)} miles`,
              startLocation: segmentStart,
              endLocation: busStop.name
            });
          }
          
          lastPoint = { lat: busStop.lat, lng: busStop.lng };
          segmentStart = busStop.name;
        }
        
        // Add walking segment from last transit stop to destination
        if (segmentStart !== "Destination") {
          const walkingDistance = distance * (Math.abs(endLat - lastPoint.lat) / Math.abs(endLat - startLat));
          // If walk is more than 2 miles, use transit, otherwise walk
          if (walkingDistance > 3200) { // More than 2 miles
            transitSegments.push({
              type: transitPoints.stations.length > 0 ? "train" : "bus",
              line: transitPoints.stations.length > 0 ? `Line ${Math.floor(Math.random() * 20) + 1}` : `Route ${Math.floor(Math.random() * 100) + 1}`,
              name: transitPoints.stations.length > 0 ? "Express Transit" : "Local Bus",
              duration: formatDuration(duration * (Math.abs(endLat - lastPoint.lat) / Math.abs(endLat - startLat))),
              distance: `${Math.round(walkingDistance / 1609.34)} miles`,
              startLocation: segmentStart,
              endLocation: "Destination"
            });
          } else {
            // Add a walking segment for the last part
            transitSegments.push({
              type: "walk",
              name: "Walking",
              duration: formatDuration(walkingDistance / 1.4), // Walking is slower than transit
              distance: `${Math.round(walkingDistance / 1609.34)} miles`,
              startLocation: segmentStart,
              endLocation: "Destination"
            });
          }
        }
        
        transitInfo = {
          segments: transitSegments
        };
        
        // Add all stations and bus stops to rest areas for display
        transitPoints.stations.forEach(station => {
          restAreas.push({
            lat: station.lat,
            lng: station.lng,
            name: station.name,
            amenities: ["Tickets", "Waiting Area", "Information", "Restrooms", "Food"],
            distanceFromStart: station.distanceFromStart,
            timeFromStart: formatDuration(duration * (Math.abs(station.lat - startLat) / Math.abs(endLat - startLat)))
          });
        });
        
        transitPoints.busStops.forEach(stop => {
          restAreas.push({
            lat: stop.lat,
            lng: stop.lng,
            name: stop.name,
            amenities: ["Bus Stop", "Bench", "Schedule"],
            distanceFromStart: `${Math.round(distance * (Math.abs(stop.lat - startLat) / Math.abs(endLat - startLat)) / 1609.34)} miles from start`,
            timeFromStart: formatDuration(duration * (Math.abs(stop.lat - startLat) / Math.abs(endLat - startLat)))
          });
        });
      }
      
      // Update stops text based on transport mode
      let stopsText = `${stops} rest areas available`;
      if (transportMode === "flight") {
        stopsText = restAreas.length > 0 ? 
          `${restAreas.length} connection${restAreas.length > 1 ? 's' : ''}` : 
          `Non-stop flight`;
      } else if (transportMode === "transit") {
        const trainStationCount = restAreas.filter(area => area.name.includes("Train Station")).length;
        const busStopCount = restAreas.filter(area => area.name.includes("Bus Stop")).length;
        const walkSegmentCount = transitInfo?.segments.filter(segment => segment.type === "walk").length || 0;
        stopsText = `${trainStationCount} train station${trainStationCount !== 1 ? 's' : ''}, ${busStopCount} bus stop${busStopCount !== 1 ? 's' : ''}, ${walkSegmentCount} walking segment${walkSegmentCount !== 1 ? 's' : ''}`;
      }
      
      return {
        distance: `${Math.round(distance / 1609.34)} miles`, // Convert meters to miles
        duration: formatDuration(duration),
        path: coordinates,
        stops: stopsText,
        restAreas,
        tolls,
        transportMode, // Include the transport mode in the response
        transitInfo // Add transit-specific information
      };
    } catch (error) {
      console.error("Route error:", error);
      return null;
    }
  }
  
  function sampleRoutePoints(path: Array<{lat: number, lng: number}>, numPoints: number) {
    if (path.length <= numPoints) return path;
    
    const result = [path[0]]; // Always include start point
    
    const step = (path.length - 1) / (numPoints - 1);
    
    for (let i = 1; i < numPoints - 1; i++) {
      const index = Math.floor(i * step);
      result.push(path[index]);
    }
    
    result.push(path[path.length - 1]); // Always include end point
    
    return result;
  }
  
  function formatDuration(seconds: number) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    return `Approx. ${hours} ${hours === 1 ? 'hr' : 'hrs'} ${minutes} min`;
  }

  // AI routes
  app.post("/api/ai/route-recommendation", handleRouteRecommendation);
  app.post("/api/ai/weather-risk-assessment", handleWeatherRiskAssessment);
  app.post("/api/ai/trip-planning-assistance", handleTripPlanningAssistance);
  app.post("/api/ai/natural-language-query", handleNaturalLanguageQuery);
  app.post("/api/ai/personalized-recommendations", handlePersonalizedRecommendations);
  app.post("/api/ai/weather-based-detours", handleWeatherBasedDetours);
  app.post("/api/ai/weather-adjusted-travel-time", handleWeatherAdjustedTravelTime);

  const httpServer = createServer(app);

  return httpServer;
}
