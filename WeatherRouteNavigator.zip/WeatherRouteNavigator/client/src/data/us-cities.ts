// List of popular US cities for autocomplete
export const usCities = [
  // Major cities by population
  { name: "New York", state: "NY" },
  { name: "Los Angeles", state: "CA" },
  { name: "Chicago", state: "IL" },
  { name: "Houston", state: "TX" },
  { name: "Phoenix", state: "AZ" },
  { name: "Philadelphia", state: "PA" },
  { name: "San Antonio", state: "TX" },
  { name: "San Diego", state: "CA" },
  { name: "Dallas", state: "TX" },
  { name: "San Jose", state: "CA" },
  { name: "Austin", state: "TX" },
  { name: "Jacksonville", state: "FL" },
  { name: "Fort Worth", state: "TX" },
  { name: "Columbus", state: "OH" },
  { name: "San Francisco", state: "CA" },
  { name: "Charlotte", state: "NC" },
  { name: "Indianapolis", state: "IN" },
  { name: "Seattle", state: "WA" },
  { name: "Denver", state: "CO" },
  { name: "Washington", state: "DC" },
  { name: "Boston", state: "MA" },
  { name: "El Paso", state: "TX" },
  { name: "Nashville", state: "TN" },
  { name: "Detroit", state: "MI" },
  { name: "Oklahoma City", state: "OK" },
  { name: "Portland", state: "OR" },
  { name: "Las Vegas", state: "NV" },
  { name: "Memphis", state: "TN" },
  { name: "Louisville", state: "KY" },
  { name: "Baltimore", state: "MD" },
  { name: "Milwaukee", state: "WI" },
  { name: "Albuquerque", state: "NM" },
  { name: "Tucson", state: "AZ" },
  { name: "Fresno", state: "CA" },
  { name: "Sacramento", state: "CA" },
  { name: "Long Beach", state: "CA" },
  { name: "Kansas City", state: "MO" },
  { name: "Mesa", state: "AZ" },
  { name: "Atlanta", state: "GA" },
  { name: "Colorado Springs", state: "CO" },
  { name: "Raleigh", state: "NC" },
  { name: "Omaha", state: "NE" },
  { name: "Miami", state: "FL" },
  { name: "Oakland", state: "CA" },
  { name: "Minneapolis", state: "MN" },
  { name: "Tulsa", state: "OK" },
  { name: "Cleveland", state: "OH" },
  { name: "Wichita", state: "KS" },
  { name: "New Orleans", state: "LA" },
  { name: "Tampa", state: "FL" },
  
  // Popular tourist destinations
  { name: "Orlando", state: "FL" },
  { name: "Honolulu", state: "HI" },
  { name: "Santa Fe", state: "NM" },
  { name: "Charleston", state: "SC" },
  { name: "Savannah", state: "GA" },
  { name: "Napa", state: "CA" },
  { name: "Sedona", state: "AZ" },
  { name: "Key West", state: "FL" },
  { name: "Aspen", state: "CO" },
  { name: "Myrtle Beach", state: "SC" },
  { name: "Santa Barbara", state: "CA" },
  { name: "Monterey", state: "CA" },
  { name: "Park City", state: "UT" },
  { name: "Virginia Beach", state: "VA" },
  { name: "Maui", state: "HI" },
  { name: "St. Augustine", state: "FL" },
  { name: "Lake Tahoe", state: "CA" },
  { name: "Yosemite", state: "CA" },
  { name: "Yellowstone", state: "WY" },
  { name: "Grand Canyon", state: "AZ" },
  { name: "Salt Lake City", state: "UT" },
  { name: "St. Louis", state: "MO" },
  { name: "Pittsburgh", state: "PA" },
  { name: "Cincinnati", state: "OH" },
  { name: "Buffalo", state: "NY" },
  { name: "Richmond", state: "VA" },
  { name: "Baton Rouge", state: "LA" },
  { name: "Boise", state: "ID" },
  { name: "Des Moines", state: "IA" },
  { name: "Jackson", state: "MS" }
];

// Get formatted city name with state
export function getFullCityName(city: {name: string, state: string}): string {
  return `${city.name}, ${city.state}`;
}

// Search for cities based on input text
export function searchCities(query: string): {name: string, state: string}[] {
  if (!query || query.length < 2) return [];
  
  const lowerQuery = query.toLowerCase();
  return usCities.filter(city => {
    const fullName = getFullCityName(city).toLowerCase();
    return fullName.includes(lowerQuery) || city.name.toLowerCase().includes(lowerQuery);
  }).slice(0, 5); // Limit to 5 results
}