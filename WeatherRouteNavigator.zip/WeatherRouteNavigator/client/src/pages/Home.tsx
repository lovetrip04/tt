import React, { useState, useEffect } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import AppHeader from "@/components/AppHeader";
import Sidebar from "@/components/Sidebar";
import MapContainer from "@/components/MapContainer";
import { RouteInfo, WeatherForecast, MapSettings } from "@shared/schema";
import { format } from "date-fns";

export default function Home() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [routeInfo, setRouteInfo] = useState<RouteInfo | null>(null);
  const [weatherForecasts, setWeatherForecasts] = useState<Record<string, WeatherForecast[]>>({});
  const [mapSettings, setMapSettings] = useState<MapSettings>({
    showRestAreas: true,
    showTolls: true,
    showTemperatures: true,
    showWeather: true
  });
  
  const isMobile = useIsMobile();
  const { toast } = useToast();
  
  // Mutation for planning a trip
  const planTripMutation = useMutation({
    mutationFn: async (formData: {
      startLocation: string;
      endLocation: string;
      startDate?: Date;
      endDate?: Date;
      transportMode?: string;
      settings?: MapSettings;
    }) => {
      // Format dates as ISO strings if they exist
      const formattedStartDate = formData.startDate ? format(formData.startDate, "yyyy-MM-dd") : undefined;
      const formattedEndDate = formData.endDate ? format(formData.endDate, "yyyy-MM-dd") : undefined;
      
      const data = {
        startLocation: formData.startLocation,
        endLocation: formData.endLocation,
        startDate: formattedStartDate,
        endDate: formattedEndDate,
        transportMode: formData.transportMode || "driving"
      };
      return apiRequest<any>("/api/route-weather", {
        method: "POST",
        body: JSON.stringify(data)
      });
    },
    onSuccess: (data) => {
      // Set route info
      setRouteInfo({
        distance: data.trip.distance,
        duration: data.trip.duration,
        path: data.route.path,
        stops: data.trip.stops,
        transportMode: data.trip.transportMode || "driving", // Default to driving if not provided
        restAreas: data.route.restAreas,
        tolls: data.route.tolls,
        transitInfo: data.route.transitInfo
      });
      
      // Set weather forecasts
      setWeatherForecasts(data.forecasts);
      
      toast({
        title: "Trip Planned Successfully",
        description: `Route from ${data.trip.startLocation} to ${data.trip.endLocation} has been planned with weather forecasts.`,
      });
    },
    onError: (error) => {
      console.error("Trip planning error:", error);
      toast({
        title: "Error Planning Trip",
        description: error instanceof Error ? error.message : "Failed to plan trip. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  // Handle form submission
  const handlePlanTrip = (formData: any) => {
    planTripMutation.mutate(formData);
  };
  
  // Handle sidebar toggle
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  // Handle weather refresh
  const handleRefreshWeather = () => {
    if (planTripMutation.variables) {
      planTripMutation.mutate(planTripMutation.variables);
    }
  };
  
  // Handle map settings change
  const handleMapSettingsChange = (newSettings: Partial<MapSettings>) => {
    console.log("Map settings change:", newSettings);
    setMapSettings(prev => {
      const updatedSettings = { ...prev, ...newSettings };
      console.log("Updated map settings:", updatedSettings);
      return updatedSettings;
    });
  };
  
  return (
    <div className="bg-neutral-100 h-screen flex flex-col">
      <AppHeader />
      
      <div className="flex flex-1 overflow-hidden">
        <Sidebar 
          isMobile={isMobile}
          sidebarOpen={sidebarOpen}
          toggleSidebar={toggleSidebar}
          tripDistance={routeInfo?.distance || ""}
          tripDuration={routeInfo?.duration || ""}
          tripStops={routeInfo?.stops || ""}
          weatherForecasts={weatherForecasts}
          isLoading={planTripMutation.isPending}
          onSubmitTrip={handlePlanTrip}
          onRefreshWeather={handleRefreshWeather}
          mapSettings={mapSettings}
          onMapSettingsChange={handleMapSettingsChange}
          transportMode={routeInfo?.transportMode}
          transitInfo={routeInfo?.transitInfo}
          startLocation={planTripMutation.variables?.startLocation}
          endLocation={planTripMutation.variables?.endLocation}
          routePath={routeInfo?.path}
        />
        
        <MapContainer 
          routePath={routeInfo?.path}
          weatherForecasts={weatherForecasts}
          transportMode={routeInfo?.transportMode}
          restAreas={routeInfo?.restAreas}
          tolls={routeInfo?.tolls}
          transitInfo={routeInfo?.transitInfo}
          mapSettings={mapSettings}
          onShowSidebar={toggleSidebar}
        />
      </div>
    </div>
  );
}
