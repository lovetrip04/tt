import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Clock, MapPin, TrafficCone } from "lucide-react";

interface TripSummaryProps {
  distance: string;
  duration: string;
  stops: string;
}

export default function TripSummary({ distance, duration, stops }: TripSummaryProps) {
  return (
    <Card className="border-0 shadow-none">
      <CardContent className="p-4 border-t border-neutral-200">
        <h3 className="font-semibold text-neutral-800 mb-2">Trip Summary</h3>
        <div className="space-y-3">
          <div className="flex items-center">
            <TrafficCone className="text-neutral-600 h-5 w-5 mr-3" />
            <span className="text-neutral-800">{distance}</span>
          </div>
          <div className="flex items-center">
            <Clock className="text-neutral-600 h-5 w-5 mr-3" />
            <span className="text-neutral-800">{duration}</span>
          </div>
          <div className="flex items-center">
            <MapPin className="text-neutral-600 h-5 w-5 mr-3" />
            <span className="text-neutral-800">{stops}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
