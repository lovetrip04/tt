import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardFooter } from "@/components/ui/card";
import { 
  Wind, 
  Sun, 
  Cloud, 
  CloudDrizzle, 
  CloudRain, 
  CloudSnow, 
  CloudLightning, 
  CloudFog,
  CloudSun,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import { format } from "date-fns";
import { WeatherForecast } from "@shared/schema";
import TimeOfDayWeather from "./TimeOfDayWeather";
import { Button } from "@/components/ui/button";

interface WeatherCardProps {
  forecast: WeatherForecast;
}

export default function WeatherCard({ forecast }: WeatherCardProps) {
  const [showHourly, setShowHourly] = useState(false);
  
  // Parse the date string
  const date = new Date(forecast.date);
  
  // Determine card header color based on weather condition
  const getHeaderClass = () => {
    const condition = forecast.condition.toLowerCase();
    if (condition.includes("rain") || condition.includes("drizzle") || condition.includes("shower")) {
      return "bg-blue-500 text-white";
    } else if (condition.includes("cloud")) {
      return "bg-slate-400 text-white";
    } else if (condition.includes("sun") || condition.includes("clear")) {
      return "bg-amber-400 text-white";
    }
    return "bg-primary text-white";
  };
  
  // Get the correct weather icon based on condition
  const WeatherIcon = () => {
    const iconName = forecast.icon;
    const iconSize = 48;
    const iconColor = getIconColor();
    
    const props = {
      size: iconSize,
      className: `text-${iconColor}`,
      strokeWidth: 1.5
    };
    
    switch(iconName) {
      case 'sun':
        return <Sun {...props} />;
      case 'cloud-sun':
        return <CloudSun {...props} />;
      case 'cloud':
        return <Cloud {...props} />;
      case 'cloud-drizzle':
        return <CloudDrizzle {...props} />;
      case 'cloud-rain':
        return <CloudRain {...props} />;
      case 'cloud-snow':
        return <CloudSnow {...props} />;
      case 'cloud-lightning':
        return <CloudLightning {...props} />;
      case 'cloud-fog':
        return <CloudFog {...props} />;
      default:
        return <Sun {...props} />;
    }
  };
  
  const getIconColor = () => {
    const condition = forecast.condition.toLowerCase();
    if (condition.includes("rain") || condition.includes("drizzle")) {
      return "blue-500";
    } else if (condition.includes("cloud")) {
      return "slate-500";
    } else if (condition.includes("sun") || condition.includes("clear")) {
      return "amber-400";
    }
    return "gray-600";
  };

  const toggleHourly = () => {
    setShowHourly(!showHourly);
  };

  // Check if we have time of day data
  const hasTimeOfDayData = forecast.morningWeather || forecast.afternoonWeather || 
                           forecast.eveningWeather || forecast.nightWeather;

  return (
    <Card className="mb-3 overflow-hidden shadow">
      <CardHeader className={`flex items-center justify-between p-3 ${getHeaderClass()}`}>
        <div className="font-medium">{format(date, "MMMM d, yyyy")}</div>
        <div className="text-sm">{forecast.location}</div>
      </CardHeader>
      <CardContent className="p-3 flex items-center justify-between">
        <div className="flex items-center">
          <div className="flex justify-center items-center w-14 h-14">
            <WeatherIcon />
          </div>
          <div className="ml-2">
            <div className="text-2xl font-medium">{forecast.temperature}</div>
            <div className="text-neutral-600">{forecast.condition}</div>
          </div>
        </div>
        <div className="text-right">
          <div>H: {forecast.highTemp}</div>
          <div>L: {forecast.lowTemp}</div>
          <div className="flex items-center text-neutral-600">
            <Wind className="h-4 w-4 mr-1" />
            <span>{forecast.windSpeed}</span>
          </div>
        </div>
      </CardContent>
      
      {hasTimeOfDayData && (
        <CardFooter className="p-2 border-t flex flex-col space-y-1">
          <div className="w-full flex justify-between items-center mb-1">
            <span className="text-xs font-medium text-neutral-500">Time of day forecast</span>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-6 w-6" 
              onClick={toggleHourly}
            >
              {showHourly ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </Button>
          </div>
          
          {showHourly && (
            <div className="w-full flex flex-col space-y-2">
              <TimeOfDayWeather 
                title="Morning" 
                timeRange="6am - 12pm" 
                weather={forecast.morningWeather} 
              />
              <TimeOfDayWeather 
                title="Afternoon" 
                timeRange="12pm - 6pm" 
                weather={forecast.afternoonWeather} 
              />
              <TimeOfDayWeather 
                title="Evening" 
                timeRange="6pm - 12am" 
                weather={forecast.eveningWeather} 
              />
              <TimeOfDayWeather 
                title="Night" 
                timeRange="12am - 6am" 
                weather={forecast.nightWeather} 
              />
            </div>
          )}
        </CardFooter>
      )}
    </Card>
  );
}
