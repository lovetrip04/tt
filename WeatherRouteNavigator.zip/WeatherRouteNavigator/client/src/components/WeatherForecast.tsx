import React from "react";
import { Button } from "@/components/ui/button";
import { RefreshCw, MapPin } from "lucide-react";
import WeatherCard from "./WeatherCard";
import { WeatherForecast as WeatherForecastType } from "@shared/schema";

interface WeatherForecastProps {
  forecasts: Record<string, WeatherForecastType[]>;
  isLoading?: boolean;
  onRefresh?: () => void;
}

export default function WeatherForecast({ 
  forecasts,
  isLoading = false,
  onRefresh
}: WeatherForecastProps) {
  return (
    <div className="flex-1 overflow-auto p-4 border-t border-neutral-200">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-semibold text-neutral-800">Weather Forecast</h3>
        <div className="flex space-x-2">
          <Button 
            variant="ghost" 
            size="icon" 
            className="text-primary hover:text-primary-dark focus:outline-none"
            title="View on map"
          >
            <MapPin className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost"
            size="icon" 
            className="text-primary hover:text-primary-dark focus:outline-none"
            title="Refresh data"
            onClick={onRefresh}
            disabled={isLoading}
          >
            <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>
      
      {isLoading ? (
        <div className="text-center py-8">
          <RefreshCw className="animate-spin h-8 w-8 mx-auto text-primary mb-4" />
          <p className="text-neutral-600">Loading weather forecasts...</p>
        </div>
      ) : forecasts && Object.keys(forecasts).length > 0 ? (
        <div>
          {Object.keys(forecasts).sort().map(date => {
            // Display the first forecast for each day
            // In a real app, we might want to show multiple forecast points per day
            return forecasts[date].length > 0 && (
              <WeatherCard key={date} forecast={forecasts[date][0]} />
            );
          })}
        </div>
      ) : (
        <div className="text-center py-8">
          <p className="text-neutral-500">No weather data available. Please plan a trip to see forecasts.</p>
        </div>
      )}
    </div>
  );
}
