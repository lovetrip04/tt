import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Train, Bus, ArrowRight, Clock, Route, PersonStanding } from "lucide-react";
import { Separator } from "@/components/ui/separator";

interface TransitSegment {
  type: string;
  line?: string;
  name?: string;
  duration: string;
  distance: string;
  startLocation: string;
  endLocation: string;
  departureTime?: string;
  arrivalTime?: string;
}

interface TransitInfoProps {
  segments: TransitSegment[];
}

export default function TransitInfo({ segments }: TransitInfoProps) {
  if (!segments || segments.length === 0) {
    return null;
  }

  return (
    <Card className="border-0 shadow-none">
      <CardContent className="p-4 border-t border-neutral-200">
        <h3 className="font-semibold text-neutral-800 mb-3">Transit Directions</h3>
        <div className="space-y-4">
          {segments.map((segment, index) => (
            <div key={index} className="space-y-2">
              <div className="flex items-center">
                {segment.type === "train" ? (
                  <Train className="text-purple-600 h-5 w-5 mr-2" />
                ) : segment.type === "bus" ? (
                  <Bus className="text-blue-600 h-5 w-5 mr-2" />
                ) : segment.type === "walk" ? (
                  <PersonStanding className="text-green-600 h-5 w-5 mr-2" />
                ) : (
                  <Bus className="text-blue-600 h-5 w-5 mr-2" />
                )}
                <div className="flex-1">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">
                      {segment.type === "train" ? "Train" : 
                       segment.type === "bus" ? "Bus" : 
                       segment.type === "walk" ? "Walk" : "Transit"}{" "}
                      {segment.line && `(${segment.line})`}
                    </span>
                    <span className="text-sm text-neutral-500">{segment.duration}</span>
                  </div>
                  <div className="text-sm text-neutral-600">{segment.name}</div>
                </div>
              </div>

              <div className="flex items-stretch pl-2.5 ml-0.5 pb-0.5">
                <div className="border-l-2 border-dashed border-neutral-300"></div>
                <div className="pl-4 pt-1 pb-2 space-y-1 text-sm">
                  <div className="flex items-center justify-between gap-6">
                    <div>
                      <div className="font-medium">{segment.startLocation}</div>
                      {segment.departureTime && (
                        <div className="text-xs text-neutral-500">Departure: {segment.departureTime}</div>
                      )}
                    </div>
                    <div className="text-neutral-500">{segment.distance}</div>
                  </div>
                  <div className="flex items-center mt-2 text-xs text-neutral-500">
                    <Clock className="h-3 w-3 mr-1" />
                    <span>{segment.duration}</span>
                  </div>
                  <div className="flex items-center justify-between gap-6 mt-1">
                    <div>
                      <div className="font-medium">{segment.endLocation}</div>
                      {segment.arrivalTime && (
                        <div className="text-xs text-neutral-500">Arrival: {segment.arrivalTime}</div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {index < segments.length - 1 && (
                <div className="flex items-center justify-center py-1">
                  {segments[index + 1].type === "walk" ? (
                    <span className="text-xs text-neutral-500 font-medium">Continue walking</span>
                  ) : segment.type === "walk" ? (
                    <span className="text-xs text-neutral-500 font-medium">Board transit</span>
                  ) : (
                    <span className="text-xs text-neutral-500 font-medium">Transfer</span>
                  )}
                </div>
              )}
              
              {index < segments.length - 1 && <Separator />}
            </div>
          ))}
        </div>

        <div className="mt-4 text-xs text-center text-neutral-500">
          <span>These are estimated transit times and routes based on general schedules</span>
        </div>
      </CardContent>
    </Card>
  );
}