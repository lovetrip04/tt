import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { processNaturalLanguageQuery } from "@/lib/aiService";
import { Loader2, Search } from "lucide-react";

interface NaturalLanguageSearchProps {
  onSearchResult: (result: {
    startLocation?: string;
    endLocation?: string;
    startDate?: string;
    endDate?: string;
    transportMode?: string;
  }) => void;
}

export default function NaturalLanguageSearch({ onSearchResult }: NaturalLanguageSearchProps) {
  const [query, setQuery] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);

  const handleProcessQuery = async () => {
    if (!query.trim()) {
      toast({
        title: "Please enter a query",
        description: "Enter details about your trip in natural language.",
        variant: "destructive"
      });
      return;
    }

    setIsProcessing(true);
    
    try {
      const response = await processNaturalLanguageQuery(query);
      const result = response.parsedQuery;
      
      console.log("NLS response:", response);
      
      if (result && result.parsed && result.confidence > 0.5) {
        onSearchResult({
          startLocation: result.startLocation,
          endLocation: result.endLocation,
          startDate: result.startDate,
          endDate: result.endDate,
          transportMode: result.transportMode,
        });
        
        toast({
          title: "Query processed successfully",
          description: "We've filled in your trip details based on your request.",
        });
      } else {
        toast({
          title: "Couldn't understand query",
          description: "Please try again with more specific details about your trip.",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error("Error processing natural language query:", error);
      toast({
        title: "Error processing query",
        description: "An error occurred while processing your request. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleProcessQuery();
    }
  };

  return (
    <Card className="mb-6 shadow-md">
      <CardHeader className="pb-3">
        <CardTitle className="text-xl font-bold">Natural Language Search</CardTitle>
        <CardDescription className="text-base">
          Simply describe your trip in everyday language and let our AI figure out the details.
        </CardDescription>
        <div className="mt-2 text-sm text-muted-foreground space-y-2">
          <p>Examples you can try:</p>
          <ul className="list-disc pl-5 space-y-1">
            <li>"I want to drive from New York to Boston next weekend"</li>
            <li>"Plan a train trip from Chicago to Detroit on May 15th"</li>
            <li>"Flight from San Francisco to Seattle tomorrow"</li>
          </ul>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col space-y-4">
          <div className="relative">
            <Input
              placeholder="What is best to take family trip to Disney World next month?"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={isProcessing}
              className="w-full min-h-[80px] py-2 text-base"
            />
          </div>
          <Button 
            onClick={handleProcessQuery} 
            disabled={isProcessing}
            size="lg"
            className="self-end w-full sm:w-auto"
          >
            {isProcessing ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Processing
              </>
            ) : (
              <>
                <Search className="mr-2 h-5 w-5" />
                Search
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}