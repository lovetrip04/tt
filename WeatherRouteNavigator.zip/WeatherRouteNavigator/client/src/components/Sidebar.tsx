import React, { useState } from "react";
import TripForm from "./TripForm";
import TripSummary from "./TripSummary";
import WeatherForecast from "./WeatherForecast";
import TransitInfo from "./TransitInfo";
import AIFeatures from "./AIFeatures";
import { WeatherForecast as WeatherForecastType, MapSettings, RouteInfo } from "@shared/schema";
import { 
  ChevronLeft, 
  ChevronRight, 
  MapPin, 
  ThermometerSnowflake, 
  Cloud, 
  Receipt, 
  Map,
  Navigation,
  LayoutDashboard,
  CloudSun,
  Settings,
  Train,
  Brain
} from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Switch } from "./ui/switch";
import { Label } from "./ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface SidebarProps {
  isMobile: boolean;
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  tripDistance: string;
  tripDuration: string;
  tripStops: string;
  weatherForecasts: Record<string, WeatherForecastType[]>;
  isLoading: boolean;
  onSubmitTrip: (data: any) => void;
  onRefreshWeather?: () => void;
  mapSettings?: MapSettings;
  onMapSettingsChange?: (settings: Partial<MapSettings>) => void;
  transportMode?: string;
  startLocation?: string;
  endLocation?: string;
  routePath?: Array<{lat: number, lng: number}>;
  transitInfo?: {
    segments: Array<{
      type: string;
      line?: string;
      name?: string;
      duration: string;
      distance: string;
      startLocation: string;
      endLocation: string;
      departureTime?: string;
      arrivalTime?: string;
    }>;
  };
}

export default function Sidebar({
  isMobile,
  sidebarOpen,
  toggleSidebar,
  tripDistance,
  tripDuration,
  tripStops,
  weatherForecasts,
  isLoading,
  onSubmitTrip,
  onRefreshWeather,
  mapSettings,
  onMapSettingsChange,
  transportMode,
  transitInfo,
  startLocation,
  endLocation,
  routePath
}: SidebarProps) {
  const [activeTab, setActiveTab] = useState<string>("plan");
  const hasTripData = tripDistance && tripDuration && tripStops;
  
  return (
    <>
      {/* Bottom app bar for mobile */}
      {isMobile && (
        <div className="fixed bottom-0 left-0 right-0 bg-white shadow-lg z-30 border-t border-gray-200">
          <div className="grid grid-cols-3 h-16">
            <button 
              className={`flex flex-col items-center justify-center text-xs ${activeTab === "plan" ? "text-blue-600" : "text-gray-500"}`}
              onClick={() => {
                setActiveTab("plan");
                if (!sidebarOpen) toggleSidebar();
              }}
            >
              <Navigation className="h-5 w-5 mb-1" />
              Plan Trip
            </button>
            <button 
              className={`flex flex-col items-center justify-center text-xs ${activeTab === "map" ? "text-blue-600" : "text-gray-500"}`}
              onClick={() => {
                if (sidebarOpen) toggleSidebar();
              }}
            >
              <Map className="h-5 w-5 mb-1" />
              Map View
            </button>
            <button 
              className={`flex flex-col items-center justify-center text-xs ${activeTab === "settings" || activeTab === "weather" ? "text-blue-600" : "text-gray-500"}`}
              onClick={() => {
                setActiveTab(hasTripData ? "weather" : "settings");
                if (!sidebarOpen) toggleSidebar();
              }}
            >
              {hasTripData ? (
                <>
                  <CloudSun className="h-5 w-5 mb-1" />
                  Weather
                </>
              ) : (
                <>
                  <Settings className="h-5 w-5 mb-1" />
                  Options
                </>
              )}
            </button>
          </div>
        </div>
      )}
      
      {/* Sidebar toggle button for desktop view */}
      {!isMobile && !sidebarOpen && (
        <div className="absolute top-20 left-0 z-20">
          <Button 
            variant="default" 
            size="sm" 
            className="rounded-l-none shadow-md bg-primary-light" 
            onClick={toggleSidebar}
          >
            <ChevronRight className="h-5 w-5" />
          </Button>
        </div>
      )}
      
      <aside 
        className={`sidebar bg-white flex flex-col shadow-lg z-10 transition-all duration-300 ease-in-out ${
          isMobile 
            ? 'w-full absolute pb-16' // Add padding for mobile bottom bar
            : sidebarOpen 
              ? 'md:w-1/3 lg:w-1/4' 
              : 'w-0 opacity-0 overflow-hidden'
        }`}
        style={{
          height: '100%',
          transform: isMobile && !sidebarOpen ? 'translateX(-100%)' : 'translateX(0)',
        }}
      >
        {/* Header for desktop or tablet */}
        {!isMobile && (
          <div className="p-3 bg-primary-light text-white sticky top-0 z-10">
            <div className="flex justify-between items-center">
              <h2 className="font-semibold text-lg">Weather Trip</h2>
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-white" 
                onClick={toggleSidebar}
              >
                <ChevronLeft className="h-5 w-5" />
              </Button>
            </div>
          </div>
        )}

        {/* Mobile header with tabs */}
        {isMobile && (
          <div className="sticky top-0 z-10 bg-white border-b">
            <div className="flex justify-between items-center p-3">
              <h2 className="font-semibold text-blue-600 text-lg">Weather<span className="text-gray-800">Trip</span></h2>
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-gray-600" 
                onClick={toggleSidebar}
              >
                <ChevronLeft className="h-5 w-5" />
              </Button>
            </div>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="w-full">
                <TabsTrigger value="plan" className="flex-1 text-xs data-[state=active]:bg-blue-50">
                  <Navigation className="h-4 w-4 mr-1" />
                  Plan
                </TabsTrigger>
                {hasTripData && (
                  <TabsTrigger value="weather" className="flex-1 text-xs data-[state=active]:bg-blue-50">
                    <CloudSun className="h-4 w-4 mr-1" />
                    Weather
                  </TabsTrigger>
                )}
                {hasTripData && (
                  <TabsTrigger value="ai" className="flex-1 text-xs data-[state=active]:bg-blue-50">
                    <Brain className="h-4 w-4 mr-1" />
                    AI
                  </TabsTrigger>
                )}
                <TabsTrigger value="settings" className="flex-1 text-xs data-[state=active]:bg-blue-50">
                  <Settings className="h-4 w-4 mr-1" />
                  Options
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        )}

        {/* Scrollable content area with tabs for mobile */}
        <div className="flex-1 overflow-y-auto custom-scrollbar">
          {isMobile ? (
            <Tabs value={activeTab} className="w-full">
              <TabsContent value="plan" className="m-0">
                <TripForm onSubmit={onSubmitTrip} isLoading={isLoading} />
              </TabsContent>
              
              <TabsContent value="weather" className="m-0">
                <WeatherForecast 
                  forecasts={weatherForecasts} 
                  isLoading={isLoading}
                  onRefresh={onRefreshWeather}
                />
              </TabsContent>
              
              <TabsContent value="ai" className="m-0 p-4">
                <AIFeatures
                  startLocation={startLocation}
                  endLocation={endLocation}
                  routePath={routePath}
                  weatherForecasts={weatherForecasts}
                  onSearchResult={(result) => {
                    if (result) {
                      onSubmitTrip(result);
                    }
                  }}
                />
              </TabsContent>
              
              <TabsContent value="settings" className="m-0 p-4">
                {hasTripData && (
                  <TripSummary 
                    distance={tripDistance} 
                    duration={tripDuration} 
                    stops={tripStops} 
                  />
                )}
                
                {/* Show Transit Information if available and in transit mode */}
                {transitInfo && transitInfo.segments && transitInfo.segments.length > 0 && transportMode === "transit" && (
                  <TransitInfo segments={transitInfo.segments} />
                )}
                
                {mapSettings && (
                  <Card className="mt-4 shadow-sm">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Map Display Options</CardTitle>
                      <CardDescription>Customize what you see on the map</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Cloud className="h-4 w-4 text-sky-500" />
                            <Label htmlFor="show-weather">Weather</Label>
                          </div>
                          <Switch 
                            id="show-weather" 
                            checked={mapSettings?.showWeather || false}
                            onCheckedChange={(checked) => {
                              console.log("Toggling weather to:", checked);
                              onMapSettingsChange?.({ showWeather: checked });
                            }}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <ThermometerSnowflake className="h-4 w-4 text-blue-500" />
                            <Label htmlFor="show-temperatures">Temperatures</Label>
                          </div>
                          <Switch 
                            id="show-temperatures" 
                            checked={mapSettings?.showTemperatures || false}
                            onCheckedChange={(checked) => {
                              console.log("Toggling temperatures to:", checked);
                              onMapSettingsChange?.({ showTemperatures: checked });
                            }}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <MapPin className="h-4 w-4 text-green-500" />
                            <Label htmlFor="show-rest-areas">Rest Areas</Label>
                          </div>
                          <Switch 
                            id="show-rest-areas" 
                            checked={mapSettings?.showRestAreas || false}
                            onCheckedChange={(checked) => {
                              console.log("Toggling rest areas to:", checked);
                              onMapSettingsChange?.({ showRestAreas: checked });
                            }}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Receipt className="h-4 w-4 text-orange-500" />
                            <Label htmlFor="show-tolls">Toll Roads</Label>
                          </div>
                          <Switch 
                            id="show-tolls" 
                            checked={mapSettings?.showTolls || false}
                            onCheckedChange={(checked) => {
                              console.log("Toggling tolls to:", checked);
                              onMapSettingsChange?.({ showTolls: checked });
                            }}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            </Tabs>
          ) : (
            // Desktop layout - show everything scrollable
            <>
              <TripForm onSubmit={onSubmitTrip} isLoading={isLoading} />
              
              {hasTripData && (
                <TripSummary 
                  distance={tripDistance} 
                  duration={tripDuration} 
                  stops={tripStops} 
                />
              )}
              
              {/* Show Transit Information if available and in transit mode */}
              {transitInfo && transitInfo.segments && transitInfo.segments.length > 0 && transportMode === "transit" && (
                <TransitInfo segments={transitInfo.segments} />
              )}
              
              {/* AI Features Section */}
              {hasTripData && (
                <Card className="mb-4 mx-4 shadow-sm">
                  <CardHeader className="pb-2">
                    <CardTitle className="flex items-center">
                      <Brain className="mr-2 h-5 w-5 text-primary" />
                      AI Trip Assistant
                    </CardTitle>
                    <CardDescription>
                      Get AI-powered insights for your trip
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <AIFeatures
                      startLocation={startLocation}
                      endLocation={endLocation}
                      routePath={routePath}
                      weatherForecasts={weatherForecasts}
                      onSearchResult={(result) => {
                        if (result) {
                          onSubmitTrip(result);
                        }
                      }}
                    />
                  </CardContent>
                </Card>
              )}
              
              <WeatherForecast 
                forecasts={weatherForecasts} 
                isLoading={isLoading}
                onRefresh={onRefreshWeather}
              />
              
              {/* Map Settings Panel */}
              {mapSettings && hasTripData && (
                <Card className="mb-4 mx-4 shadow-sm">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Map Settings</CardTitle>
                    <CardDescription>Customize your map display</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Cloud className="h-4 w-4 text-slate-500" />
                          <Label htmlFor="show-weather">Weather</Label>
                        </div>
                        <Switch 
                          id="show-weather" 
                          checked={mapSettings?.showWeather || false}
                          onCheckedChange={(checked) => {
                            console.log("Desktop: Toggling weather to:", checked);
                            onMapSettingsChange?.({ showWeather: checked });
                          }}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <ThermometerSnowflake className="h-4 w-4 text-blue-500" />
                          <Label htmlFor="show-temperatures">Temperatures</Label>
                        </div>
                        <Switch 
                          id="show-temperatures" 
                          checked={mapSettings?.showTemperatures || false}
                          onCheckedChange={(checked) => {
                            console.log("Desktop: Toggling temperatures to:", checked);
                            onMapSettingsChange?.({ showTemperatures: checked });
                          }}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <MapPin className="h-4 w-4 text-green-500" />
                          <Label htmlFor="show-rest-areas">Rest Areas</Label>
                        </div>
                        <Switch 
                          id="show-rest-areas" 
                          checked={mapSettings?.showRestAreas || false}
                          onCheckedChange={(checked) => {
                            console.log("Desktop: Toggling rest areas to:", checked);
                            onMapSettingsChange?.({ showRestAreas: checked });
                          }}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Receipt className="h-4 w-4 text-orange-500" />
                          <Label htmlFor="show-tolls">Toll Information</Label>
                        </div>
                        <Switch 
                          id="show-tolls" 
                          checked={mapSettings?.showTolls || false}
                          onCheckedChange={(checked) => {
                            console.log("Desktop: Toggling tolls to:", checked);
                            onMapSettingsChange?.({ showTolls: checked });
                          }}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </div>
      </aside>
    </>
  );
}
