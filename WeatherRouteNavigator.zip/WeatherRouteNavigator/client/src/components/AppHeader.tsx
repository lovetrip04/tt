import React from "react";
import { Link } from "wouter";

export default function AppHeader() {
  const [menuOpen, setMenuOpen] = React.useState(false);

  return (
    <header className="bg-primary text-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 mr-2">
            <path d="M10.5 1.5H8.25A2.25 2.25 0 0 0 6 3.75v16.5a2.25 2.25 0 0 0 2.25 2.25h7.5A2.25 2.25 0 0 0 18 20.25V3.75a2.25 2.25 0 0 0-2.25-2.25H13.5m-3 0V3h3V1.5m-3 0a2.25 2.25 0 0 0-2.25 2.25v16.5A2.25 2.25 0 0 0 10.5 22.5h3a2.25 2.25 0 0 0 2.25-2.25V3.75a2.25 2.25 0 0 0-2.25-2.25h-3m-3.75 3h7.5m-7.5 3h7.5m-7.5 3h7.5m-7.5 3h7.5" />
          </svg>
          <h1 className="font-bold text-xl">WeatherTrip</h1>
        </div>
        <nav className="hidden md:block">
          <ul className="flex space-x-6">
            <li><Link href="/"><a className="hover:text-secondary-light transition-colors">Home</a></Link></li>
            <li><a href="#" className="hover:text-secondary-light transition-colors">My Trips</a></li>
            <li><a href="#" className="hover:text-secondary-light transition-colors">Help</a></li>
          </ul>
        </nav>
        <button 
          className="md:hidden text-white focus:outline-none"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>
      
      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden bg-primary-dark">
          <ul className="flex flex-col py-2 px-4">
            <li className="py-2"><Link href="/"><a className="hover:text-secondary-light transition-colors">Home</a></Link></li>
            <li className="py-2"><a href="#" className="hover:text-secondary-light transition-colors">My Trips</a></li>
            <li className="py-2"><a href="#" className="hover:text-secondary-light transition-colors">Help</a></li>
          </ul>
        </div>
      )}
    </header>
  );
}
