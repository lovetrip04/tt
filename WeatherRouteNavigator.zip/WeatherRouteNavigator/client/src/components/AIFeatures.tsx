import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Brain, Route, AlertCircle } from "lucide-react";
import NaturalLanguageSearch from "./NaturalLanguageSearch";
import WeatherRiskAssessment from "./WeatherRiskAssessment";
import RouteRecommendation from "./RouteRecommendation";

interface AIFeaturesProps {
  startLocation?: string;
  endLocation?: string;
  routePath?: Array<{lat: number, lng: number}>;
  weatherForecasts?: Record<string, any[]>;
  onSearchResult: (result: {
    startLocation?: string;
    endLocation?: string;
    startDate?: string;
    endDate?: string;
    transportMode?: string;
  }) => void;
}

export default function AIFeatures({
  startLocation,
  endLocation,
  routePath,
  weatherForecasts,
  onSearchResult
}: AIFeaturesProps) {
  const [activeFeatures, setActiveFeatures] = useState({
    naturalLanguage: true,
    routeRecommendation: true,
    weatherRisk: true
  });

  const handleToggleFeature = (feature: keyof typeof activeFeatures) => {
    setActiveFeatures(prev => ({
      ...prev,
      [feature]: !prev[feature]
    }));
  };

  return (
    <Tabs defaultValue="search" className="w-full">
      <div className="flex items-center justify-between mb-4">
        <TabsList>
          <TabsTrigger value="search">Search</TabsTrigger>
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
          <TabsTrigger value="risks">Risks</TabsTrigger>
        </TabsList>
        <div className="flex items-center space-x-2">
          <Brain className="h-4 w-4 text-muted-foreground" />
          <Label className="text-xs text-muted-foreground">AI Features</Label>
        </div>
      </div>

      <TabsContent value="search" className="mt-0">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="nlp-toggle" className="text-sm cursor-pointer">Enable Natural Language Search</Label>
            <Switch 
              id="nlp-toggle" 
              checked={activeFeatures.naturalLanguage} 
              onCheckedChange={() => handleToggleFeature('naturalLanguage')}
            />
          </div>
          
          {activeFeatures.naturalLanguage && (
            <NaturalLanguageSearch onSearchResult={onSearchResult} />
          )}
        </div>
      </TabsContent>

      <TabsContent value="recommendations" className="mt-0">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Route className="h-4 w-4" />
              <Label htmlFor="route-toggle" className="text-sm cursor-pointer">Smart Route Recommendations</Label>
            </div>
            <Switch 
              id="route-toggle" 
              checked={activeFeatures.routeRecommendation} 
              onCheckedChange={() => handleToggleFeature('routeRecommendation')}
            />
          </div>
          
          <RouteRecommendation 
            startLocation={startLocation}
            endLocation={endLocation}
            weatherForecasts={weatherForecasts}
            isActive={activeFeatures.routeRecommendation}
          />
        </div>
      </TabsContent>

      <TabsContent value="risks" className="mt-0">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <AlertCircle className="h-4 w-4" />
              <Label htmlFor="risk-toggle" className="text-sm cursor-pointer">Weather Risk Assessment</Label>
            </div>
            <Switch 
              id="risk-toggle" 
              checked={activeFeatures.weatherRisk} 
              onCheckedChange={() => handleToggleFeature('weatherRisk')}
            />
          </div>
          
          <WeatherRiskAssessment 
            routePath={routePath}
            weatherForecasts={weatherForecasts}
            isActive={activeFeatures.weatherRisk}
          />
        </div>
      </TabsContent>
    </Tabs>
  );
}