import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, Route, Map } from "lucide-react";
import { getRouteRecommendation, AIRouteRecommendation } from "@/lib/aiService";
import { toast } from "@/hooks/use-toast";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";

interface RouteRecommendationProps {
  startLocation?: string;
  endLocation?: string;
  weatherForecasts?: Record<string, any[]>;
  isActive: boolean;
}

export default function RouteRecommendation({ 
  startLocation, 
  endLocation, 
  weatherForecasts, 
  isActive 
}: RouteRecommendationProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [recommendation, setRecommendation] = useState<AIRouteRecommendation | null>(null);
  
  const handleGetRecommendation = async () => {
    if (!startLocation || !endLocation || !weatherForecasts) {
      toast({
        title: "Missing information",
        description: "Please plan a trip first to get route recommendations.",
        variant: "destructive"
      });
      return;
    }
    
    setIsLoading(true);
    
    // Dummy preferences for now, could be expanded in the future with user input
    const preferences = {
      avoidRain: true,
      prioritizeDaylight: true,
      weatherSensitivity: "medium"
    };
    
    try {
      const result = await getRouteRecommendation(
        startLocation,
        endLocation,
        weatherForecasts,
        preferences
      );
      
      setRecommendation(result);
      
      toast({
        title: "Recommendation ready",
        description: "We've generated an optimal route recommendation for your trip.",
      });
    } catch (error) {
      console.error("Error getting route recommendation:", error);
      toast({
        title: "Error getting recommendation",
        description: "An error occurred while generating your route recommendation. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  if (!isActive) return null;
  
  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Route className="mr-2 h-5 w-5" />
          Route Recommendation
        </CardTitle>
        <CardDescription>
          Get an AI-powered optimal route based on weather conditions
        </CardDescription>
      </CardHeader>
      <CardContent>
        {!recommendation ? (
          <Button onClick={handleGetRecommendation} disabled={isLoading || !startLocation || !endLocation}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Map className="mr-2 h-4 w-4" />
                Get Optimal Route
              </>
            )}
          </Button>
        ) : (
          <div className="space-y-4">
            <div className="p-3 bg-muted rounded-md">
              <h4 className="font-medium mb-1">Optimal Route:</h4>
              <p>{recommendation.optimalRoute.path}</p>
              <p className="text-sm mt-2"><span className="font-medium">Suggested Timing:</span> {recommendation.optimalRoute.timing}</p>
            </div>
            
            <div>
              <h4 className="font-medium mb-2">Weather Conditions Avoided:</h4>
              <div className="flex flex-wrap gap-2">
                {recommendation.optimalRoute.avoidedWeather.map((weather, idx) => (
                  <Badge key={idx} variant="secondary">{weather}</Badge>
                ))}
              </div>
            </div>
            
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="reasoning">
                <AccordionTrigger>See Reasoning</AccordionTrigger>
                <AccordionContent>
                  <p className="text-sm text-muted-foreground whitespace-pre-line">
                    {recommendation.reasoning}
                  </p>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
            
            <Button onClick={handleGetRecommendation} className="w-full mt-4" variant="outline">
              Refresh Recommendation
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}