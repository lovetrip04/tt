import React from "react";
import { Button } from "@/components/ui/button";
import { Plus, Minus, Compass } from "lucide-react";

interface MapControlsProps {
  onZoomIn: () => void;
  onZoomOut: () => void;
  onMyLocation: () => void;
}

export default function MapControls({ onZoomIn, onZoomOut, onMyLocation }: MapControlsProps) {
  return (
    <div className="absolute top-4 right-4 bg-white rounded-lg shadow-md p-2 flex flex-col space-y-2">
      <Button 
        variant="ghost" 
        size="icon" 
        className="w-8 h-8 p-0"
        onClick={onZoomIn}
      >
        <Plus className="h-4 w-4" />
      </Button>
      <Button 
        variant="ghost" 
        size="icon" 
        className="w-8 h-8 p-0"
        onClick={onZoomOut}
      >
        <Minus className="h-4 w-4" />
      </Button>
      <div className="border-t border-neutral-200 my-1 w-full"></div>
      <Button 
        variant="ghost" 
        size="icon" 
        className="w-8 h-8 p-0"
        onClick={onMyLocation}
      >
        <Compass className="h-4 w-4" />
      </Button>
    </div>
  );
}
