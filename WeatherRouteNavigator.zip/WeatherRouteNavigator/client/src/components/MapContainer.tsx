import React, { useEffect, useState } from "react";
import MapControls from "./MapControls";
import MapLegend from "./MapLegend";
import { Menu, CloudRain, AlertCircle, CloudDrizzle, Droplets, Cloud, Sun, Car, Bike, Train, Bus, PersonStanding, Clock, MapPin } from "lucide-react";
import { Button } from "./ui/button";
import { WeatherForecast } from "@shared/schema";
import { 
  MapContainer as LeafletMapContainer, 
  TileLayer, 
  Marker, 
  Popup, 
  Polyline, 
  useMap,
  Circle,
  CircleMarker,
  Tooltip
} from "react-leaflet";
import { Icon, LatLngBounds, LatLngExpression, divIcon } from "leaflet";
import "leaflet/dist/leaflet.css";
import { format, parseISO, addDays } from "date-fns";

// Fix for the default marker icon in Leaflet
import iconRetinaUrl from 'leaflet/dist/images/marker-icon-2x.png';
import iconUrl from 'leaflet/dist/images/marker-icon.png';
import shadowUrl from 'leaflet/dist/images/marker-shadow.png';
import L from 'leaflet';

delete (L.Icon.Default.prototype as any)._getIconUrl;

L.Icon.Default.mergeOptions({
  iconRetinaUrl,
  iconUrl,
  shadowUrl,
});

// Custom icons for start, end and weather markers
const createCustomIcon = (color: string, text?: string) => {
  return new Icon({
    iconUrl,
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowUrl,
    shadowSize: [41, 41],
    className: text ? 'weather-marker' : '',
    html: text ? `<div class="marker-text">${text}</div>` : undefined
  });
};

// Component to handle map bounds when route changes
function FitBounds({ points }: { points: Array<[number, number]> }) {
  const map = useMap();
  
  useEffect(() => {
    if (points.length > 0) {
      const bounds = new LatLngBounds(points.map(p => [p[0], p[1]]));
      map.fitBounds(bounds, { padding: [80, 80] });
    }
  }, [points, map]);
  
  return null;
}

// Component to handle current location button
function MyLocationControl({ onMyLocation }: { onMyLocation: () => void }) {
  const map = useMap();
  
  const handleMyLocation = () => {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        map.flyTo(
          [position.coords.latitude, position.coords.longitude],
          10
        );
        onMyLocation();
      },
      (error) => {
        console.error("Error getting location:", error);
      }
    );
  };
  
  return null;
}

interface MapContainerProps {
  routePath?: Array<{lat: number, lng: number}>;
  weatherForecasts?: Record<string, WeatherForecast[]>;
  transportMode?: string;
  restAreas?: Array<{
    lat: number;
    lng: number;
    name: string;
    amenities: string[];
    distanceFromStart: string;
    timeFromStart: string;
  }>;
  tolls?: Array<{
    location: string;
    cost: string;
    lat: number;
    lng: number;
  }>;
  transitInfo?: {
    segments: Array<{
      type: string;
      line?: string;
      name?: string;
      duration: string;
      distance: string;
      startLocation: string;
      endLocation: string;
      departureTime?: string;
      arrivalTime?: string;
    }>;
  };
  mapSettings?: {
    showRestAreas: boolean;
    showTolls: boolean;
    showTemperatures: boolean;
    showWeather: boolean;
  };
  onShowSidebar: () => void;
}

// Extended weather point type with position info
interface WeatherPointWithPosition extends WeatherForecast {
  position: LatLngExpression;
  hasRain: boolean;
  dayOffset: number;
}

export default function MapContainer({ 
  routePath, 
  weatherForecasts, 
  transportMode = "driving", 
  restAreas, 
  tolls,
  transitInfo,
  mapSettings = {
    showRestAreas: true,
    showTolls: true,
    showTemperatures: true,
    showWeather: true
  },
  onShowSidebar 
}: MapContainerProps) {
  const [zoom, setZoom] = useState(5);
  const [selectedDay, setSelectedDay] = useState(0); // 0 = today, 1 = tomorrow, etc.
  const [rainyAreas, setRainyAreas] = useState<Array<{position: LatLngExpression, intensity: number}>>([]);
  const [weatherPoints, setWeatherPoints] = useState<WeatherPointWithPosition[]>([]);
  
  // Add an effect to log when mapSettings change
  useEffect(() => {
    console.log("MapContainer received settings:", mapSettings);
  }, [mapSettings.showWeather, mapSettings.showTemperatures, mapSettings.showRestAreas, mapSettings.showTolls]);
  
  // Format route path for Leaflet
  const routePoints: LatLngExpression[] = routePath 
    ? routePath.map(point => [point.lat, point.lng] as LatLngExpression)
    : [];
  
  // Process weather forecasts to identify rainy areas and prepare visualization
  useEffect(() => {
    if (weatherForecasts && Object.keys(weatherForecasts).length > 0 && mapSettings.showWeather) {
      const today = new Date();
      const sortedDates = Object.keys(weatherForecasts).sort();
      const daysWithForecasts = Math.min(sortedDates.length, 10); // Max 10 days
      
      // Process all available forecast dates
      const allPoints: WeatherPointWithPosition[] = [];
      const rainPoints: Array<{position: LatLngExpression, intensity: number}> = [];
      
      // For each date in the forecast
      sortedDates.forEach((dateStr, dateIndex) => {
        const forecasts = weatherForecasts[dateStr] || [];
        
        // For each location forecast on this date
        forecasts.forEach(forecast => {
          const position = [forecast.lat, forecast.lng] as LatLngExpression;
          
          // Check if this has rain conditions
          const condition = forecast.condition.toLowerCase();
          const hasRain = condition.includes('rain') || 
                          condition.includes('drizzle') || 
                          condition.includes('shower') ||
                          condition.includes('thunder');
          
          // Add to all weather points
          allPoints.push({
            ...forecast,
            position,
            hasRain,
            dayOffset: dateIndex
          });
          
          // If it's the selected day and it has rain, add to rain areas visualization
          if (dateIndex === selectedDay && hasRain) {
            // Determine intensity based on keywords in condition
            let intensity = 0.5; // Default medium
            
            if (condition.includes('heavy') || condition.includes('storm')) {
              intensity = 0.8; // Heavy rain
            } else if (condition.includes('light') || condition.includes('drizzle')) {
              intensity = 0.3; // Light rain
            }
            
            rainPoints.push({
              position,
              intensity
            });
          }
        });
      });
      
      setWeatherPoints(allPoints);
      setRainyAreas(rainPoints);
    } else {
      setWeatherPoints([]);
      setRainyAreas([]);
    }
  }, [weatherForecasts, selectedDay, mapSettings.showWeather, mapSettings.showTemperatures, mapSettings.showRestAreas, mapSettings.showTolls]);
  
  // Get only weather points for the selected day
  const visibleWeatherPoints = weatherPoints.filter(p => p.dayOffset === selectedDay);
  
  // Determine if there's rain on any days in the forecast
  const rainyDays = Array.from({ length: 10 }, (_, i) => {
    return weatherPoints.some(p => p.dayOffset === i && p.hasRain);
  });
  
  // Map control handlers
  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev + 1, 18));
  };
  
  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev - 1, 1));
  };
  
  const handleMyLocation = () => {
    // This is handled by the MyLocationControl component
  };

  // Get transport mode icon
  const getTransportModeIcon = () => {
    switch(transportMode) {
      case 'driving':
        return <Car className="h-4 w-4" />;
      case 'walking':
        return <PersonStanding className="h-4 w-4" />;
      case 'cycling':
        return <Bike className="h-4 w-4" />;
      case 'transit':
        return <Train className="h-4 w-4" />;
      default:
        return <Car className="h-4 w-4" />;
    }
  };
  
  // Get transport mode label
  const getTransportModeLabel = () => {
    switch(transportMode) {
      case 'driving':
        return 'Driving';
      case 'walking':
        return 'Walking';
      case 'cycling':
        return 'Cycling';
      case 'transit':
        return 'Transit';
      default:
        return 'Driving';
    }
  };

  return (
    <main className="flex-1 relative">
      <div className="absolute inset-0 bg-gray-200">
        {/* Mobile toggle for map/sidebar */}
        <Button 
          id="show-sidebar" 
          className="absolute top-4 left-4 bg-white p-3 rounded-full shadow-lg z-[1000]"
          onClick={onShowSidebar}
          aria-label="Show sidebar"
        >
          <Menu className="h-5 w-5" />
        </Button>
        
        {/* Transport mode indicator */}
        {routePoints.length > 1 && (
          <div className="absolute top-4 right-4 bg-white rounded-md shadow-md z-[1000] px-3 py-2 flex items-center">
            <div className="mr-2 text-sm font-medium">Mode:</div>
            <div className="flex items-center bg-blue-100 rounded px-2 py-1">
              {getTransportModeIcon()}
              <span className="ml-1 text-sm font-medium">{getTransportModeLabel()}</span>
            </div>
          </div>
        )}
        
        {/* Day selector for weather */}
        {weatherPoints.length > 0 && mapSettings.showWeather && (
          <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-white rounded-md shadow-md z-[1000] p-1 flex">
            {Array.from({ length: Math.min(10, rainyDays.length) }, (_, i) => {
              const date = addDays(new Date(), i);
              const hasRainOnDay = rainyDays[i];
              
              return (
                <button
                  key={`day-${i}`}
                  className={`px-2 py-1 text-xs rounded ${
                    selectedDay === i ? 'bg-blue-600 text-white' : 'hover:bg-gray-100'
                  } mx-0.5 flex items-center ${hasRainOnDay ? 'font-bold' : ''}`}
                  onClick={() => setSelectedDay(i)}
                >
                  {format(date, 'MMM d')}
                  {hasRainOnDay && <CloudRain className="h-3 w-3 ml-1 text-red-500" />}
                </button>
              );
            })}
          </div>
        )}
        
        {/* Rain alert if present */}
        {mapSettings.showWeather && rainyAreas.length > 0 && (
          <div className="absolute top-14 left-1/2 transform -translate-x-1/2 bg-red-50 border border-red-200 rounded-md shadow-md z-[1000] p-2 flex items-center text-sm text-red-700">
            <AlertCircle className="h-4 w-4 mr-2" />
            <div>
              <strong>Weather Alert:</strong> Rain expected at {rainyAreas.length} {rainyAreas.length === 1 ? 'location' : 'locations'} on your route
            </div>
          </div>
        )}
        
        {/* OpenStreetMap using Leaflet */}
        <LeafletMapContainer 
          center={[35.782169, -80.793457]} 
          zoom={zoom} 
          style={{ height: '100%', width: '100%' }}
          zoomControl={false}
          attributionControl={false}
        >
          {/* Base map layer */}
          <TileLayer
            attribution=''
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          
          {/* Route polyline */}
          {routePoints.length > 1 && (
            <>
              <Polyline 
                positions={routePoints}
                color="#1976D2"
                weight={5}
                dashArray="5,5"
              />
              
              {/* Route temperature points - add markers at intervals */}
              {mapSettings.showTemperatures && Array.isArray(routePoints) && routePoints.length > 5 && 
                // Sample a few points along the route for temperature
                [
                  Math.floor(routePoints.length * 0.25),
                  Math.floor(routePoints.length * 0.5),
                  Math.floor(routePoints.length * 0.75)
                ].map((index, i) => {
                  // Find nearest weather point
                  const routePoint = routePoints[index];
                  if (!routePoint || !Array.isArray(routePoint)) return null;
                  
                  if (weatherPoints.length === 0) return null;
                  
                  // Determine if this point should be offset based on its position in the array (0, 1, 2, 3)
                  // Create different offsets for each point to prevent overlap
                  const offsets = [
                    [0.015, -0.015],  // First point offset northeast
                    [-0.015, -0.015], // Second point offset northwest 
                    [0.015, 0.015],   // Third point offset southeast
                    [-0.015, 0.015]   // Fourth point offset southwest
                  ];
                  
                  const [offsetLat, offsetLng] = offsets[i];
                  
                  // Find closest weather point to this route point by simple distance calculation
                  let closestWeatherPoint = weatherPoints[0]; // Default to first point
                  let minDistance = Infinity;
                  
                  for (const point of weatherPoints) {
                    if (!point || !point.position) continue;
                    const latLng = point.position as [number, number];
                    const distance = Math.sqrt(
                      Math.pow(latLng[0] - routePoint[0], 2) + 
                      Math.pow(latLng[1] - routePoint[1], 2)
                    );
                    
                    if (distance < minDistance) {
                      minDistance = distance;
                      closestWeatherPoint = point;
                    }
                  }
                  
                  // Different direction for each temperature point to prevent tooltip overlap
                  const tooltipDirections = ["top", "right", "bottom", "left"];
                  const tooltipDirection = tooltipDirections[i] as any;
                  
                  return (
                    <CircleMarker
                      key={`route-temp-${i}`}
                      // Apply the calculated offset for this point
                      center={[
                        (routePoint as [number, number])[0] + offsetLat,
                        (routePoint as [number, number])[1] + offsetLng
                      ]}
                      radius={5}
                      pathOptions={{
                        color: "#1976D2",
                        fillColor: "#ffffff",
                        fillOpacity: 0.9,
                        weight: 2
                      }}
                    >
                      <Tooltip permanent direction={tooltipDirection} offset={[0, -10]} className="temperature-tooltip">
                        <span className="font-bold">{closestWeatherPoint?.temperature || ''}</span>
                      </Tooltip>
                    </CircleMarker>
                  );
                })
              }
            </>
          )}
          
          {/* Start point marker */}
          {routePoints.length > 0 && (
            <Marker 
              position={routePoints[0]}
              icon={new Icon({
                iconUrl: iconUrl,
                iconSize: [25, 41],
                iconAnchor: [12, 41],
                popupAnchor: [1, -34],
                shadowUrl: shadowUrl,
                shadowSize: [41, 41],
                className: 'start-marker'
              })}
            >
              <Popup>Starting Point</Popup>
            </Marker>
          )}
          
          {/* End point marker */}
          {routePoints.length > 1 && (
            <Marker 
              position={routePoints[routePoints.length - 1]}
              icon={new Icon({
                iconUrl: iconUrl,
                iconSize: [25, 41],
                iconAnchor: [12, 41],
                popupAnchor: [1, -34],
                shadowUrl: shadowUrl,
                shadowSize: [41, 41],
                className: 'end-marker'
              })}
            >
              <Popup>Destination</Popup>
            </Marker>
          )}
          
          {/* Toll markers */}
          {tolls && mapSettings.showTolls && tolls.map((toll, index) => (
            <Marker
              key={`toll-${index}`}
              position={[toll.lat, toll.lng]}
              icon={L.divIcon({
                className: 'toll-marker',
                html: `<div class="bg-blue-600 p-2 rounded-full border-2 border-white shadow-lg flex items-center justify-center">
                  <span class="text-white text-xs font-bold">$</span>
                </div>`,
                iconSize: [28, 28],
                iconAnchor: [14, 14]
              })}
            >
              <Popup className="toll-popup">
                <div className="p-2 min-w-[200px]">
                  <h3 className="font-bold text-blue-700 mb-1">Toll Booth</h3>
                  <div className="grid grid-cols-2 gap-2 mt-2 text-sm">
                    <div className="col-span-2">
                      <span className="font-medium">{toll.location}</span>
                    </div>
                    <div className="col-span-2">
                      <span className="font-medium">Cost: {toll.cost}</span>
                    </div>
                  </div>
                </div>
              </Popup>
            </Marker>
          ))}
          
          {/* Rest area markers */}
          {restAreas && mapSettings.showRestAreas && restAreas.map((restArea, index) => (
            <Marker
              key={`rest-area-${index}`}
              position={[restArea.lat, restArea.lng]}
              icon={L.divIcon({
                className: 'rest-area-marker',
                html: `<div class="bg-green-600 p-2 rounded-full border-2 border-white shadow-lg flex items-center justify-center">
                  <span class="text-white text-xs font-bold">RA</span>
                </div>`,
                iconSize: [28, 28],
                iconAnchor: [14, 14]
              })}
            >
              <Popup className="rest-area-popup">
                <div className="p-2 min-w-[220px]">
                  <h3 className="font-bold text-green-700 mb-1">{restArea.name}</h3>
                  
                  <div className="grid grid-cols-2 gap-2 mt-2 text-sm">
                    <div className="col-span-2">
                      <span className="font-medium">{restArea.distanceFromStart}</span>
                    </div>
                    <div className="col-span-2">
                      <span className="font-medium">Travel time: {restArea.timeFromStart}</span>
                    </div>
                  </div>
                  
                  <div className="mt-3">
                    <h4 className="font-medium text-sm mb-1">Amenities:</h4>
                    <div className="flex flex-wrap gap-1">
                      {restArea.amenities.map((amenity, i) => (
                        <span key={`amenity-${i}`} className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">
                          {amenity}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </Popup>
            </Marker>
          ))}
          
          {/* Rain areas visualization */}
          {mapSettings.showWeather && rainyAreas.map((area, index) => (
            <Circle
              key={`rain-area-${index}`}
              center={area.position}
              radius={15000} // 15km radius to show rain area
              pathOptions={{
                color: '#e74c3c',
                fillColor: '#e74c3c',
                fillOpacity: area.intensity * 0.3,
                weight: 1
              }}
            >
              <Tooltip direction="bottom" permanent offset={[0, 10]} className="rain-tooltip">
                <div className="flex items-center text-xs">
                  <CloudRain className="h-3 w-3 mr-1 text-red-500" />
                  Rain
                </div>
              </Tooltip>
            </Circle>
          ))}
          
          {/* Weather markers */}
          {mapSettings.showWeather && visibleWeatherPoints.map((point, index) => (
            <CircleMarker
              key={`weather-${index}`}
              center={point.position}
              radius={point.hasRain ? 8 : 6}
              pathOptions={{
                color: point.hasRain
                  ? '#e74c3c'  // Rain - red
                  : point.condition.toLowerCase().includes('cloud')
                    ? '#95a5a6'  // Cloudy - gray
                    : '#f39c12',  // Sunny - amber
                fillColor: point.hasRain
                  ? '#e74c3c'  // Rain
                  : point.condition.toLowerCase().includes('cloud')
                    ? '#95a5a6'  // Cloudy
                    : '#f39c12',  // Sunny
                fillOpacity: 0.7,
                weight: 2
              }}
            >
              <Popup>
                <div className="p-2 min-w-[200px]">
                  <div className="flex justify-between items-center mb-1">
                    <h3 className="font-bold">{point.location}</h3>
                    <div className="text-sm text-gray-500">
                      {format(parseISO(point.date), 'MMM d, yyyy')}
                    </div>
                  </div>
                  
                  <div className="flex items-center my-2">
                    {point.hasRain ? (
                      <CloudRain className="h-8 w-8 mr-3 text-red-500" />
                    ) : (
                      <div className="h-8 w-8 mr-3 flex items-center justify-center">
                        {point.condition.toLowerCase().includes('cloud') ? (
                          <Cloud className="h-8 w-8 text-gray-500" />
                        ) : (
                          <Sun className="h-8 w-8 text-amber-500" />
                        )}
                      </div>
                    )}
                    <div>
                      <div className="font-medium">{point.condition}</div>
                      <div className="text-2xl font-bold">{point.temperature}</div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 mt-2 text-sm">
                    <div>High: <span className="font-medium">{point.highTemp}</span></div>
                    <div>Low: <span className="font-medium">{point.lowTemp}</span></div>
                    <div className="col-span-2">Wind: <span className="font-medium">{point.windSpeed}</span></div>
                  </div>
                </div>
              </Popup>
            </CircleMarker>
          ))}
          
          {/* Transit station markers */}
          {transitInfo && transportMode === 'transit' && transitInfo.segments.map((segment, index) => {
            // Only create markers for stations (not for walking segments)
            if (segment.type === 'walk') return null;
            
            // Extract coordinates from the route path at the segment's start and end
            // We need to find the closest points in the route to the station names
            if (!routePath || routePath.length < 2) return null;
            
            // Simple approach: find points in the route path approximately at segment boundaries
            // In a real application, we would have the exact coordinates from the transit API
            const segmentIndex = index;
            const segmentsCount = transitInfo.segments.length;
            
            // Calculate position along the route path
            const startIdx = Math.max(0, Math.floor((segmentIndex / segmentsCount) * routePath.length));
            const startPosition = routePath[startIdx];
            
            return (
              <Marker
                key={`transit-station-${index}`}
                position={[startPosition.lat, startPosition.lng]}
                icon={L.divIcon({
                  className: 'transit-station-marker',
                  html: `<div class="bg-purple-600 p-2 rounded-full border-2 border-white shadow-lg flex items-center justify-center">
                    <span class="text-white text-xs font-bold">${segment.type === 'train' ? 'T' : 'B'}</span>
                  </div>`,
                  iconSize: [28, 28],
                  iconAnchor: [14, 14]
                })}
              >
                <Popup className="transit-station-popup">
                  <div className="p-2 min-w-[220px]">
                    <div className="flex items-center">
                      <div className={`mr-2 p-1 rounded-full ${
                        segment.type === 'train' ? 'bg-purple-600' : 'bg-blue-600'
                      }`}>
                        {segment.type === 'train' ? (
                          <Train className="h-4 w-4 text-white" />
                        ) : (
                          <Bus className="h-4 w-4 text-white" />
                        )}
                      </div>
                      <h3 className="font-bold text-purple-700">{segment.type === 'train' ? 'Train Station' : 'Bus Stop'}</h3>
                    </div>
                    
                    <div className="grid gap-2 mt-2 text-sm">
                      {segment.line && (
                        <div className="flex items-center">
                          <span className="font-medium mr-1">Line:</span>
                          <span className="bg-purple-100 text-purple-800 px-2 py-0.5 rounded text-xs">{segment.line}</span>
                        </div>
                      )}
                      
                      <div>
                        <div className="font-medium">{segment.startLocation}</div>
                        {segment.departureTime && (
                          <div className="text-xs text-gray-600">Departs: {segment.departureTime}</div>
                        )}
                      </div>
                      
                      <div className="flex items-center text-xs text-gray-600">
                        <Clock className="h-3 w-3 mr-1" />
                        <span>{segment.duration}</span>
                        <span className="mx-1">•</span>
                        <MapPin className="h-3 w-3 mr-1" />
                        <span>{segment.distance}</span>
                      </div>
                      
                      <div>
                        <div className="font-medium">{segment.endLocation}</div>
                        {segment.arrivalTime && (
                          <div className="text-xs text-gray-600">Arrives: {segment.arrivalTime}</div>
                        )}
                      </div>
                    </div>
                  </div>
                </Popup>
              </Marker>
            );
          })}
          
          {/* Fit map to route bounds when route changes */}
          {routePoints.length > 0 && (
            <FitBounds points={routePoints.map(point => 
              Array.isArray(point) ? [point[0], point[1]] : [point.lat, point.lng]
            )} />
          )}
          
          {/* My location control */}
          <MyLocationControl onMyLocation={handleMyLocation} />
        </LeafletMapContainer>
        
        {/* Map controls */}
        <div className="absolute top-4 right-4 z-[1000]">
          <MapControls 
            onZoomIn={handleZoomIn} 
            onZoomOut={handleZoomOut} 
            onMyLocation={handleMyLocation} 
          />
        </div>
        
        {/* Map legend */}
        <div className="absolute bottom-4 right-4 z-[1000]">
          <MapLegend />
        </div>
      </div>
    </main>
  );
}
