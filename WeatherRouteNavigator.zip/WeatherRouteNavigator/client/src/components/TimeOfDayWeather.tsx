import React from "react";
import { TimeOfDayWeather as TimeOfDayWeatherType } from "@shared/schema";
import { 
  Sun, 
  Cloud, 
  CloudDrizzle, 
  CloudRain, 
  CloudSun,
  LucideIcon,
  Clock
} from "lucide-react";

interface TimeOfDayWeatherProps {
  title: string;
  timeRange: string;
  weather?: TimeOfDayWeatherType;
}

export default function TimeOfDayWeather({ title, timeRange, weather }: TimeOfDayWeatherProps) {
  if (!weather) {
    return (
      <div className="p-2 border rounded-md flex items-center justify-between opacity-60">
        <div className="flex items-center">
          <Clock className="h-4 w-4 mr-1" />
          <div className="text-xs font-medium">{title}</div>
        </div>
        <div className="text-xs text-neutral-500">{timeRange}</div>
        <div className="text-xs text-neutral-400">No data</div>
      </div>
    );
  }

  // Get the correct weather icon based on condition
  const WeatherIcon = (): React.ReactElement => {
    const iconName = weather.icon;
    const iconSize = 16;
    
    const iconProps = {
      size: iconSize,
      className: getIconClass(),
      strokeWidth: 1.5
    };
    
    switch(iconName) {
      case 'sun':
        return <Sun {...iconProps} />;
      case 'cloud-sun':
        return <CloudSun {...iconProps} />;
      case 'cloud':
        return <Cloud {...iconProps} />;
      case 'cloud-drizzle':
        return <CloudDrizzle {...iconProps} />;
      case 'cloud-rain':
        return <CloudRain {...iconProps} />;
      default:
        return <Sun {...iconProps} />;
    }
  };
  
  const getIconClass = () => {
    const condition = weather.condition.toLowerCase();
    if (condition.includes("rain") || condition.includes("drizzle")) {
      return "text-blue-500";
    } else if (condition.includes("cloud")) {
      return "text-slate-500";
    } else if (condition.includes("sun") || condition.includes("clear")) {
      return "text-amber-400";
    }
    return "text-gray-600";
  };

  return (
    <div className="p-2 border rounded-md flex items-center justify-between">
      <div className="flex items-center">
        <Clock className="h-4 w-4 mr-1" />
        <div className="text-xs font-medium">{title}</div>
      </div>
      <div className="text-xs text-neutral-500">{timeRange}</div>
      <div className="flex items-center">
        <WeatherIcon />
        <div className="text-xs font-medium ml-1">{weather.temperature}</div>
        <div className="text-xs text-blue-500 ml-2">{weather.precipitationProbability}</div>
      </div>
    </div>
  );
}