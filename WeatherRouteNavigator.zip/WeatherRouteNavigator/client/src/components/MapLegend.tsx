import React, { useState } from "react";
import { CloudRain, Cloud, Sun, Info, ChevronUp, ChevronDown, MapPin, Home } from "lucide-react";

export default function MapLegend() {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
  };

  return (
    <div 
      className={`bg-white rounded-lg shadow-md p-2 max-w-[180px] text-[11px] transition-all duration-300 ${
        isCollapsed ? 'bg-opacity-90' : ''
      }`}
    >
      <div 
        className={`font-medium flex items-center justify-between cursor-pointer ${
          isCollapsed ? 'border-0' : 'border-b border-gray-200 pb-1'
        }`}
        onClick={toggleCollapse}
      >
        <div className="flex items-center">
          <MapPin className="h-3 w-3 mr-1 text-blue-600" />
          <span className="text-[11px]">Map Legend</span>
        </div>
        <div className="flex">
          {isCollapsed && (
            <div className="flex mr-1 gap-0.5">
              <span className="inline-block w-2 h-2 bg-[#f39c12] rounded-full"></span>
              <span className="inline-block w-2 h-2 bg-[#95a5a6] rounded-full"></span>
              <span className="inline-block w-2 h-2 bg-[#e74c3c] rounded-full"></span>
            </div>
          )}
          {isCollapsed ? (
            <ChevronDown className="h-3 w-3" />
          ) : (
            <ChevronUp className="h-3 w-3" />
          )}
        </div>
      </div>
      
      {!isCollapsed && (
        <div className="space-y-1 mt-1 text-[10px]">
          <div className="grid grid-cols-2 gap-0.5">
            <div className="flex items-center">
              <div className="inline-block w-2.5 h-2.5 bg-[#f39c12] mr-1 rounded-full"></div>
              <span>Sunny</span>
            </div>
            
            <div className="flex items-center">
              <div className="inline-block w-2.5 h-2.5 bg-[#95a5a6] mr-1 rounded-full"></div>
              <span>Cloudy</span>
            </div>
            
            <div className="flex items-center">
              <div className="inline-block w-2.5 h-2.5 bg-[#e74c3c] mr-1 rounded-full"></div>
              <span>Rain</span>
            </div>
          </div>
          
          <div>
            <h5 className="font-medium border-b pb-0.5 mb-0.5 mt-1 text-[10px]">Rain Areas</h5>
            <div className="grid grid-cols-3 gap-0.5">
              <div className="flex items-center">
                <div className="mr-1 bg-[#e74c3c] w-3 h-2 rounded-sm opacity-30"></div>
                <span>Light</span>
              </div>
              <div className="flex items-center">
                <div className="mr-1 bg-[#e74c3c] w-3 h-2 rounded-sm opacity-50"></div>
                <span>Med</span>
              </div>
              <div className="flex items-center">
                <div className="mr-1 bg-[#e74c3c] w-3 h-2 rounded-sm opacity-70"></div>
                <span>Heavy</span>
              </div>
            </div>
          </div>
          
          <div>
            <h5 className="font-medium border-b pb-0.5 mb-0.5 mt-1 text-[10px]">Markers</h5>
            <div className="flex items-center mt-0.5">
              <div className="flex items-center justify-center mr-1 w-4 h-4">
                <div className="bg-green-600 rounded-full w-3 h-3 flex items-center justify-center border border-white">
                  <span className="text-white text-[6px] font-bold">RA</span>
                </div>
              </div>
              <span>Rest Areas</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
