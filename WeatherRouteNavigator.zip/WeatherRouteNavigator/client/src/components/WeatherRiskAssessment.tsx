import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, AlertCircle, ShieldAlert, ShieldCheck } from "lucide-react";
import { getWeatherRiskAssessment, AIWeatherRisk } from "@/lib/aiService";
import { toast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

interface WeatherRiskAssessmentProps {
  routePath?: Array<{lat: number, lng: number}>;
  weatherForecasts?: Record<string, any[]>;
  isActive: boolean;
}

export default function WeatherRiskAssessment({ 
  routePath, 
  weatherForecasts, 
  isActive 
}: WeatherRiskAssessmentProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [riskData, setRiskData] = useState<AIWeatherRisk | null>(null);
  
  const handleAnalyzeRisks = async () => {
    if (!routePath || !weatherForecasts) {
      toast({
        title: "Missing route information",
        description: "Please plan a trip first to analyze weather risks.",
        variant: "destructive"
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      const result = await getWeatherRiskAssessment(
        { path: routePath },
        weatherForecasts
      );
      
      setRiskData(result);
      
      toast({
        title: "Risk analysis complete",
        description: "Your trip's weather risks have been analyzed.",
      });
    } catch (error) {
      console.error("Error analyzing weather risks:", error);
      toast({
        title: "Error analyzing risks",
        description: "An error occurred while analyzing weather risks. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  if (!isActive) return null;
  
  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center">
          <AlertCircle className="mr-2 h-5 w-5" />
          Weather Risk Assessment
        </CardTitle>
        <CardDescription>
          Analyze potential weather-related risks on your route
        </CardDescription>
      </CardHeader>
      <CardContent>
        {!riskData ? (
          <Button onClick={handleAnalyzeRisks} disabled={isLoading || !routePath}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <ShieldAlert className="mr-2 h-4 w-4" />
                Analyze Weather Risks
              </>
            )}
          </Button>
        ) : (
          <div className="space-y-4">
            <div>
              <h4 className="font-medium mb-2">High Risk Segments:</h4>
              {riskData.highRiskSegments.length > 0 ? (
                <div className="space-y-2">
                  {riskData.highRiskSegments.map((segment, idx) => (
                    <div key={idx} className="flex items-start space-x-2 p-2 border rounded-md">
                      <div className="mt-1">
                        <Badge 
                          variant={
                            segment.severity === 'high' 
                              ? 'destructive' 
                              : segment.severity === 'medium' 
                                ? 'default' 
                                : 'outline'
                          }
                        >
                          {segment.severity}
                        </Badge>
                      </div>
                      <div>
                        <p className="font-medium">{segment.location}</p>
                        <p className="text-sm text-muted-foreground">{segment.risk}</p>
                        <p className="text-xs text-muted-foreground">Time: {segment.timeWindow}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex items-center text-green-600 p-2">
                  <ShieldCheck className="mr-2 h-5 w-5" />
                  No high-risk segments detected
                </div>
              )}
            </div>
            
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="precautions">
                <AccordionTrigger>Safety Precautions</AccordionTrigger>
                <AccordionContent>
                  <ul className="list-disc list-inside space-y-1 pl-2">
                    {riskData.safetyPrecautions.map((precaution, idx) => (
                      <li key={idx}>{precaution}</li>
                    ))}
                  </ul>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="alternatives">
                <AccordionTrigger>Alternative Times</AccordionTrigger>
                <AccordionContent>
                  <ul className="list-disc list-inside space-y-1 pl-2">
                    {riskData.alternativeTimes.map((time, idx) => (
                      <li key={idx}>{time}</li>
                    ))}
                  </ul>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
            
            <Button onClick={handleAnalyzeRisks} className="w-full mt-4" variant="outline">
              Refresh Analysis
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}