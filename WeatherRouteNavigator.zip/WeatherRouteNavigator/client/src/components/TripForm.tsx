import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Calendar, Route, Info, Settings, MapPin, Cloud, Thermometer, Milestone, DollarSign, ArrowRight, Car, Train, Bus, Plane, Bike } from "lucide-react";
import { DatePicker } from "@/components/ui/datepicker";
import { LocationAutocomplete } from "@/components/ui/location-autocomplete";
import { format, addDays } from "date-fns";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { type MapSettings, type TransportMode } from "@shared/schema";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Define form schema
const formSchema = z.object({
  startLocation: z.string().min(2, { message: "Starting point is required" }),
  endLocation: z.string().min(2, { message: "Destination is required" }),
  transportMode: z.enum(["driving", "flight", "cycling", "transit"]).default("driving"),
  startDate: z.date().optional(),
  endDate: z.date().optional(),
  useCurrentDate: z.boolean().default(true),
  // Map settings
  settings: z.object({
    showRestAreas: z.boolean().default(true),
    showTolls: z.boolean().default(true),
    showTemperatures: z.boolean().default(true),
    showWeather: z.boolean().default(true)
  })
}).refine(data => {
  if (data.startDate && data.endDate) {
    return data.endDate >= data.startDate;
  }
  return true;
}, {
  message: "End date must be after start date",
  path: ["endDate"]
});

type FormValues = z.infer<typeof formSchema>;

interface TripFormProps {
  onSubmit: (data: FormValues) => void;
  isLoading?: boolean;
}

export default function TripForm({ onSubmit, isLoading = false }: TripFormProps) {
  const today = new Date();
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("plan");
  
  // Set up form with default values
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      startLocation: "",
      endLocation: "",
      transportMode: "driving",
      startDate: today,
      endDate: addDays(today, 7), // Default to 7 days from today
      useCurrentDate: true,
      settings: {
        showRestAreas: true,
        showTolls: true,
        showTemperatures: true,
        showWeather: true
      }
    }
  });

  const handleSubmit = (data: FormValues) => {
    // Always ensure dates are provided for weather forecasting
    if (!data.startDate) {
      data.startDate = today;
    }
    if (!data.endDate) {
      data.endDate = addDays(data.startDate, 7); // Use a week from start date if no end date
    }
    
    onSubmit(data);
  };

  const useCurrentDate = form.watch("useCurrentDate");
  const startLocation = form.watch("startLocation");
  const endLocation = form.watch("endLocation");

  const goToOptionsTab = () => {
    setActiveTab("options");
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="p-0 bg-white">
        {/* App-like mobile tabs for multi-step form */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full grid grid-cols-2 mb-4">
            <TabsTrigger value="plan" className="data-[state=active]:bg-blue-100 text-xs sm:text-sm">
              <MapPin className="h-3 w-3 mr-1 sm:mr-2" />
              <span className="hidden sm:inline">Plan Trip</span>
              <span className="sm:hidden">Plan Trip</span>
            </TabsTrigger>
            <TabsTrigger value="options" className="data-[state=active]:bg-blue-100 text-xs sm:text-sm">
              <Settings className="h-3 w-3 mr-1 sm:mr-2" />
              <span className="hidden sm:inline">Options</span>
              <span className="sm:hidden">Options</span>
            </TabsTrigger>
          </TabsList>

          {/* Step 1: Plan Trip (Locations and Dates combined) */}
          <TabsContent value="plan" className="px-4 space-y-5 mt-0">
            <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-3 rounded-md text-sm text-blue-700 flex items-start">
              <Info className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
              <div>
                Enter your trip details to see weather along your route.
              </div>
            </div>
            
            {/* Transportation Mode Section */}
            <div className="space-y-3">
              <h3 className="font-medium flex items-center text-neutral-800">
                <Route className="h-4 w-4 mr-2" />
                How are you traveling?
              </h3>
              
              <FormField
                control={form.control}
                name="transportMode"
                render={({ field }) => (
                  <FormItem className="space-y-1">
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="grid grid-cols-2 gap-2"
                      >
                        <FormItem className="flex items-center space-x-2 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="driving" id="plan-driving" className="sr-only peer" />
                          </FormControl>
                          <label 
                            htmlFor="plan-driving"
                            className="flex flex-1 items-center justify-center space-x-2 cursor-pointer rounded-md border-2 border-muted bg-white px-3 py-2 text-sm font-medium ring-offset-background peer-data-[state=checked]:border-blue-600 peer-data-[state=checked]:bg-blue-50 peer-data-[state=checked]:text-blue-800"
                          >
                            <Car className="mr-1 h-4 w-4" />
                            <span>Car</span>
                          </label>
                        </FormItem>
                        
                        <FormItem className="flex items-center space-x-2 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="transit" id="plan-transit" className="sr-only peer" />
                          </FormControl>
                          <label 
                            htmlFor="plan-transit"
                            className="flex flex-1 items-center justify-center space-x-2 cursor-pointer rounded-md border-2 border-muted bg-white px-3 py-2 text-sm font-medium ring-offset-background peer-data-[state=checked]:border-blue-600 peer-data-[state=checked]:bg-blue-50 peer-data-[state=checked]:text-blue-800"
                          >
                            <Train className="mr-1 h-4 w-4" />
                            <span>Transit</span>
                          </label>
                        </FormItem>
                        
                        <FormItem className="flex items-center space-x-2 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="cycling" id="plan-cycling" className="sr-only peer" />
                          </FormControl>
                          <label 
                            htmlFor="plan-cycling"
                            className="flex flex-1 items-center justify-center space-x-2 cursor-pointer rounded-md border-2 border-muted bg-white px-3 py-2 text-sm font-medium ring-offset-background peer-data-[state=checked]:border-blue-600 peer-data-[state=checked]:bg-blue-50 peer-data-[state=checked]:text-blue-800"
                          >
                            <Bike className="mr-1 h-4 w-4" />
                            <span>Cycling</span>
                          </label>
                        </FormItem>
                        
                        <FormItem className="flex items-center space-x-2 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="flight" id="plan-flight" className="sr-only peer" />
                          </FormControl>
                          <label 
                            htmlFor="plan-flight"
                            className="flex flex-1 items-center justify-center space-x-2 cursor-pointer rounded-md border-2 border-muted bg-white px-3 py-2 text-sm font-medium ring-offset-background peer-data-[state=checked]:border-blue-600 peer-data-[state=checked]:bg-blue-50 peer-data-[state=checked]:text-blue-800"
                          >
                            <Plane className="mr-1 h-4 w-4" />
                            <span>Flight</span>
                          </label>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>
            
            <Separator className="my-5" />

            {/* Locations Section */}
            <div className="space-y-5">
              <h3 className="font-medium flex items-center text-neutral-800">
                <MapPin className="h-4 w-4 mr-2" />
                Where are you traveling?
              </h3>
              
              <FormField
                control={form.control}
                name="startLocation"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-neutral-700 font-medium">Starting Point</FormLabel>
                    <FormControl>
                      <LocationAutocomplete
                        value={field.value}
                        onChange={field.onChange}
                        placeholder="Enter city (e.g. Chicago, IL)"
                        className="focus-visible:ring-blue-500 h-12 text-lg"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="endLocation"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-neutral-700 font-medium">Destination</FormLabel>
                    <FormControl>
                      <LocationAutocomplete
                        value={field.value}
                        onChange={field.onChange}
                        placeholder="Enter city (e.g. New York, NY)"
                        className="focus-visible:ring-blue-500 h-12 text-lg"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <Separator className="my-5" />
            
            {/* Dates Section */}
            <div className="space-y-3">
              <h3 className="font-medium flex items-center text-neutral-800">
                <Calendar className="h-4 w-4 mr-2" />
                When are you going?
              </h3>
              
              <FormField
                control={form.control}
                name="useCurrentDate"
                render={({ field }) => (
                  <FormItem className="flex items-center space-x-2 space-y-0 rounded-md border border-blue-100 bg-blue-50 p-3">
                    <FormControl>
                      <input 
                        type="checkbox" 
                        className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 h-4 w-4"
                        checked={field.value}
                        onChange={field.onChange}
                        id="use-current-date"
                      />
                    </FormControl>
                    <label 
                      htmlFor="use-current-date" 
                      className="text-sm text-blue-700 cursor-pointer select-none"
                    >
                      My trip starts today ({format(today, "EEE, MMM d")})
                    </label>
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-neutral-700 font-medium">Start Date</FormLabel>
                      <FormControl>
                        <DatePicker
                          date={field.value}
                          onDateChange={field.onChange}
                          placeholder="Select date"
                          className={useCurrentDate ? "opacity-50" : ""}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-neutral-700 font-medium">End Date</FormLabel>
                      <FormControl>
                        <DatePicker
                          date={field.value}
                          onDateChange={field.onChange}
                          placeholder="Select date"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="text-xs text-blue-600 bg-blue-50 p-2 rounded">
                <Info className="h-3 w-3 inline mr-1" />
                Weather forecast is available for the next 10 days only
              </div>
            </div>
            
            <div className="flex items-center gap-2 pt-2">
              <Button 
                type="button" 
                variant="outline"
                onClick={goToOptionsTab}
                className="flex-1"
              >
                Map Options
              </Button>
              <Button 
                type="submit" 
                className="flex-1 bg-blue-600 hover:bg-blue-700"
                disabled={isLoading || !startLocation || !endLocation}
              >
                <Route className="mr-2 h-4 w-4" />
                {isLoading ? "Planning..." : "Plan Trip"}
              </Button>
            </div>
          </TabsContent>

          {/* Step 2: Options */}
          <TabsContent value="options" className="px-4 space-y-4 mt-0">
            <div className="bg-blue-50 rounded-md p-3 space-y-3">
              <h3 className="font-medium flex items-center text-neutral-800">
                <Route className="h-4 w-4 mr-2" />
                Transportation Mode
              </h3>
              
              <FormField
                control={form.control}
                name="transportMode"
                render={({ field }) => (
                  <FormItem className="space-y-1">
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="grid grid-cols-2 gap-2"
                      >
                        <FormItem className="flex items-center space-x-2 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="driving" id="driving" className="sr-only peer" />
                          </FormControl>
                          <label 
                            htmlFor="driving"
                            className="flex flex-1 items-center justify-center space-x-2 cursor-pointer rounded-md border-2 border-muted bg-white px-3 py-2 text-sm font-medium ring-offset-background peer-data-[state=checked]:border-blue-600 peer-data-[state=checked]:bg-blue-50 peer-data-[state=checked]:text-blue-800"
                          >
                            <Car className="mr-1 h-4 w-4" />
                            <span>Car</span>
                          </label>
                        </FormItem>
                        
                        <FormItem className="flex items-center space-x-2 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="transit" id="transit" className="sr-only peer" />
                          </FormControl>
                          <label 
                            htmlFor="transit"
                            className="flex flex-1 items-center justify-center space-x-2 cursor-pointer rounded-md border-2 border-muted bg-white px-3 py-2 text-sm font-medium ring-offset-background peer-data-[state=checked]:border-blue-600 peer-data-[state=checked]:bg-blue-50 peer-data-[state=checked]:text-blue-800"
                          >
                            <Train className="mr-1 h-4 w-4" />
                            <span>Transit</span>
                          </label>
                        </FormItem>
                        
                        <FormItem className="flex items-center space-x-2 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="cycling" id="cycling" className="sr-only peer" />
                          </FormControl>
                          <label 
                            htmlFor="cycling"
                            className="flex flex-1 items-center justify-center space-x-2 cursor-pointer rounded-md border-2 border-muted bg-white px-3 py-2 text-sm font-medium ring-offset-background peer-data-[state=checked]:border-blue-600 peer-data-[state=checked]:bg-blue-50 peer-data-[state=checked]:text-blue-800"
                          >
                            <Bike className="mr-1 h-4 w-4" />
                            <span>Cycling</span>
                          </label>
                        </FormItem>
                        
                        <FormItem className="flex items-center space-x-2 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="flight" id="flight" className="sr-only peer" />
                          </FormControl>
                          <label 
                            htmlFor="flight"
                            className="flex flex-1 items-center justify-center space-x-2 cursor-pointer rounded-md border-2 border-muted bg-white px-3 py-2 text-sm font-medium ring-offset-background peer-data-[state=checked]:border-blue-600 peer-data-[state=checked]:bg-blue-50 peer-data-[state=checked]:text-blue-800"
                          >
                            <Plane className="mr-1 h-4 w-4" />
                            <span>Flight</span>
                          </label>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <div className="text-xs text-blue-600 bg-blue-100 p-2 rounded">
                <Info className="h-3 w-3 inline mr-1" />
                Flight mode shows direct paths with weather at departure and arrival
              </div>
            </div>
            
            <div className="bg-slate-50 rounded-md p-3 space-y-3">
              <h3 className="font-medium flex items-center text-neutral-800">
                <Settings className="h-4 w-4 mr-2" />
                Map Display Options
              </h3>
              
              <div className="space-y-4 p-1">
                <FormField
                  control={form.control}
                  name="settings.showWeather"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between space-y-0">
                      <div className="flex items-center space-x-2">
                        <Cloud className="h-4 w-4 text-sky-500" />
                        <FormLabel className="text-sm font-normal">Show Weather</FormLabel>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="settings.showTemperatures"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between space-y-0">
                      <div className="flex items-center space-x-2">
                        <Thermometer className="h-4 w-4 text-red-500" />
                        <FormLabel className="text-sm font-normal">Show Temperatures</FormLabel>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="settings.showRestAreas"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between space-y-0">
                      <div className="flex items-center space-x-2">
                        <Milestone className="h-4 w-4 text-green-500" />
                        <FormLabel className="text-sm font-normal">Show Rest Stops</FormLabel>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="settings.showTolls"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between space-y-0">
                      <div className="flex items-center space-x-2">
                        <DollarSign className="h-4 w-4 text-amber-500" />
                        <FormLabel className="text-sm font-normal">Show Toll Roads</FormLabel>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
            </div>
            
            <div className="pt-2">
              <Button 
                type="button" 
                variant="outline"
                onClick={() => setActiveTab("plan")}
                className="w-full"
              >
                Back to Trip Planning
              </Button>
              
              {(startLocation && endLocation) && (
                <Button 
                  type="submit" 
                  className="w-full bg-blue-600 hover:bg-blue-700 mt-2"
                  disabled={isLoading}
                >
                  <Route className="mr-2 h-4 w-4" />
                  {isLoading ? "Planning..." : "Plan Trip"}
                </Button>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </form>
    </Form>
  );
}
