import React, { useState, useEffect, useRef } from "react";
import { Input } from "./input";
import { searchCities, getFullCityName } from "@/data/us-cities";
import { MapPin } from "lucide-react";

interface LocationAutocompleteProps {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  className?: string;
}

export function LocationAutocomplete({
  value,
  onChange,
  placeholder,
  className
}: LocationAutocompleteProps) {
  const [query, setQuery] = useState(value);
  const [suggestions, setSuggestions] = useState<{name: string, state: string}[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Update suggestions when query changes
  useEffect(() => {
    const newSuggestions = searchCities(query);
    setSuggestions(newSuggestions);
  }, [query]);

  // Close suggestions when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setQuery(newValue);
    setShowSuggestions(true);
    onChange(newValue);
  };

  const handleSuggestionClick = (city: {name: string, state: string}) => {
    const fullCityName = getFullCityName(city);
    setQuery(fullCityName);
    onChange(fullCityName);
    setShowSuggestions(false);
  };

  return (
    <div ref={containerRef} className="relative w-full">
      <div className="relative">
        <MapPin className="absolute left-3 top-3 h-4 w-4 text-neutral-500" />
        <Input
          type="text"
          value={query}
          onChange={handleInputChange}
          placeholder={placeholder}
          className={`pl-10 pr-3 ${className}`}
          onFocus={() => setShowSuggestions(true)}
        />
      </div>
      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute z-10 mt-1 w-full rounded-md bg-white shadow-lg max-h-60 overflow-auto">
          <ul className="py-1 text-sm text-gray-800">
            {suggestions.map((city, index) => (
              <li
                key={index}
                className="px-4 py-2 hover:bg-gray-100 cursor-pointer flex items-center"
                onClick={() => handleSuggestionClick(city)}
              >
                <MapPin className="h-4 w-4 mr-2 text-primary" />
                <span>{getFullCityName(city)}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}