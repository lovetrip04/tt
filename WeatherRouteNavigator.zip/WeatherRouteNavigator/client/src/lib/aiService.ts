import { apiRequest } from "./queryClient";

export interface AIRouteRecommendation {
  optimalRoute: {
    path: string;
    timing: string;
    avoidedWeather: string[];
  };
  reasoning: string;
}

export interface AIWeatherRisk {
  highRiskSegments: Array<{
    location: string;
    risk: string;
    severity: 'low' | 'medium' | 'high';
    timeWindow: string;
  }>;
  safetyPrecautions: string[];
  alternativeTimes: string[];
}

export interface AITripPlan {
  itinerary: Array<{
    day: string;
    weather: string;
    activities: Array<{
      name: string;
      time: string;
      indoor: boolean;
      reason: string;
    }>;
  }>;
  overallSuggestion: string;
}

export interface NLPQueryResult {
  startLocation?: string;
  endLocation?: string;
  startDate?: string;
  endDate?: string;
  transportMode?: string;
  specialRequirements?: string[];
  parsed: boolean;
  confidence: number;
}

export interface PersonalizedRecommendation {
  recommendations: Array<{
    title: string;
    description: string;
    weatherConsideration: string;
    suitability: number;
  }>;
  reasoning: string;
}

export interface WeatherBasedDetour {
  detours: Array<{
    name: string;
    description: string;
    weatherBenefit: string;
    timeImpact: string;
  }>;
  originalRouteForecast: string;
}

export interface WeatherAdjustedTravelTime {
  adjustedTime: string;
  normalTime: string;
  differencePercentage: number;
  segmentBreakdown: Array<{
    segment: string;
    normalTime: string;
    adjustedTime: string;
    weatherImpact: string;
  }>;
  explanation: string;
}

// AI Service functions
export async function getRouteRecommendation(
  start: string,
  end: string,
  weatherData: any,
  preferences: any
): Promise<AIRouteRecommendation> {
  return apiRequest<AIRouteRecommendation>('/api/ai/route-recommendation', {
    method: 'POST',
    body: JSON.stringify({
      start,
      end,
      weatherData,
      preferences
    })
  });
}

export async function getWeatherRiskAssessment(
  route: any,
  weatherData: any
): Promise<AIWeatherRisk> {
  return apiRequest<AIWeatherRisk>('/api/ai/weather-risk-assessment', {
    method: 'POST',
    body: JSON.stringify({
      route,
      weatherData
    })
  });
}

export async function getTripPlanningAssistance(
  tripDetails: any,
  weatherData: any
): Promise<AITripPlan> {
  return apiRequest<AITripPlan>('/api/ai/trip-planning-assistance', {
    method: 'POST',
    body: JSON.stringify({
      tripDetails,
      weatherData
    })
  });
}

export async function processNaturalLanguageQuery(
  query: string
): Promise<{ parsedQuery: NLPQueryResult }> {
  return apiRequest<{ parsedQuery: NLPQueryResult }>('/api/ai/natural-language-query', {
    method: 'POST',
    body: JSON.stringify({
      query
    })
  });
}

export async function getPersonalizedRecommendations(
  userProfile: any,
  pastTrips: any,
  weatherData: any
): Promise<PersonalizedRecommendation> {
  return apiRequest<PersonalizedRecommendation>('/api/ai/personalized-recommendations', {
    method: 'POST',
    body: JSON.stringify({
      userProfile,
      pastTrips,
      weatherData
    })
  });
}

export async function getWeatherBasedDetours(
  originalRoute: any,
  weatherData: any
): Promise<WeatherBasedDetour> {
  return apiRequest<WeatherBasedDetour>('/api/ai/weather-based-detours', {
    method: 'POST',
    body: JSON.stringify({
      originalRoute,
      weatherData
    })
  });
}

export async function getPredictedTravelTime(
  route: any,
  weatherData: any,
  transportMode: string
): Promise<WeatherAdjustedTravelTime> {
  return apiRequest<WeatherAdjustedTravelTime>('/api/ai/weather-adjusted-travel-time', {
    method: 'POST',
    body: JSON.stringify({
      route,
      weatherData,
      transportMode
    })
  });
}