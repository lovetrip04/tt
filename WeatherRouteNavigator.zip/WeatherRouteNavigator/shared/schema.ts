import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Trip model to store recent searches
export const trips = pgTable("trips", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  startLocation: text("start_location").notNull(),
  endLocation: text("end_location").notNull(),
  startDate: text("start_date").notNull(),
  endDate: text("end_date").notNull(),
  distance: text("distance"),
  duration: text("duration"),
  createdAt: text("created_at").notNull()
});

export const insertTripSchema = createInsertSchema(trips).pick({
  userId: true,
  startLocation: true,
  endLocation: true,
  startDate: true,
  endDate: true,
  distance: true,
  duration: true,
  createdAt: true
});

// Weather point model to store weather data points along the route
export const weatherPoints = pgTable("weather_points", {
  id: serial("id").primaryKey(),
  tripId: integer("trip_id").references(() => trips.id),
  location: text("location").notNull(),
  date: text("date").notNull(),
  temperature: text("temperature").notNull(),
  condition: text("condition").notNull(),
  highTemp: text("high_temp").notNull(),
  lowTemp: text("low_temp").notNull(),
  windSpeed: text("wind_speed").notNull(),
  lat: text("lat").notNull(),
  lng: text("lng").notNull()
});

export const insertWeatherPointSchema = createInsertSchema(weatherPoints).pick({
  tripId: true,
  location: true,
  date: true,
  temperature: true,
  condition: true,
  highTemp: true,
  lowTemp: true,
  windSpeed: true,
  lat: true,
  lng: true
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertTrip = z.infer<typeof insertTripSchema>;
export type Trip = typeof trips.$inferSelect;

export type InsertWeatherPoint = z.infer<typeof insertWeatherPointSchema>;
export type WeatherPoint = typeof weatherPoints.$inferSelect;

// Extended types for client use
export type TripWithWeather = Trip & {
  weatherPoints: WeatherPoint[];
};

export type RestArea = {
  lat: number;
  lng: number;
  name: string;
  amenities: string[];
  distanceFromStart: string; // e.g. "120 miles"
  timeFromStart: string;     // e.g. "2 hours"
};

export type TransportMode = "driving" | "flight" | "cycling" | "transit";

export type RouteInfo = {
  distance: string;
  duration: string;
  path: Array<{lat: number, lng: number}>;
  stops: string;
  transportMode: TransportMode;
  restAreas?: RestArea[];
  tolls?: Array<{
    location: string;
    cost: string;
    lat: number;
    lng: number;
  }>;
  transitInfo?: {
    segments: Array<{
      type: string; // "train", "bus", "walk", etc.
      line?: string; // train/bus line
      name?: string; // name of train/bus
      duration: string;
      distance: string;
      startLocation: string;
      endLocation: string;
      departureTime?: string;
      arrivalTime?: string;
    }>;
  };
};

export type MapSettings = {
  showRestAreas: boolean;
  showTolls: boolean;
  showTemperatures: boolean;
  showWeather: boolean;
};

export type TimeOfDayWeather = {
  temperature: string;
  condition: string;
  icon: string;
  precipitationProbability: string;
};

export type WeatherForecast = {
  location: string;
  date: string;
  temperature: string;
  condition: string;
  icon: string;
  highTemp: string;
  lowTemp: string;
  windSpeed: string;
  lat: number;
  lng: number;
  // Time of day forecasts
  morningWeather?: TimeOfDayWeather;   // 6am-12pm
  afternoonWeather?: TimeOfDayWeather; // 12pm-6pm
  eveningWeather?: TimeOfDayWeather;   // 6pm-12am
  nightWeather?: TimeOfDayWeather;     // 12am-6am
};
